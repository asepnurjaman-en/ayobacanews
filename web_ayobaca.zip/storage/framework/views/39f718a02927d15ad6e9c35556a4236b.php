<footer class="ayobaca-footer bg-white">
    <div class="container">
        <div class="text-center">
            <img src="<?php echo e(url('storage/'.$global['setting'][2]->content)); ?>" alt="Logo" class="img-fluid">
            <div class="py-2">
                <b><?php echo e($global['setting'][0]->content); ?></b>
                <p><?php echo e($global['contact'][0]->content); ?></p>
                <ul class="list-unstyled">
                    <?php $__currentLoopData = $global['contact'][3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="tel:">
                            <i class="icon-phone"></i>
                            <span><?php echo e($item->content); ?></span>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $global['contact'][4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="https://wa.me/">
                            <i class="bx bxl-whatsapp"></i>
                            <span><?php echo e($item->content); ?></span>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $global['contact'][2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="mailto:">
                            <i class="icon-envelope"></i>
                            <span><?php echo e($item->content); ?></span>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <ul class="socialize">
                    <?php $__currentLoopData = $global['social'][0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="#" target="_BLANK" class="<?php echo e($item->brand); ?>" title="<?php echo e($item->title); ?>">
                            <i class="<?php echo e($item->icon); ?>"></i>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="border-top border-bottom py-4">
        <div class="container">
            <div class="row justify-content-center">
                <?php $__currentLoopData = $global['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-6 text-center">
                    <a href="<?php echo e(route('l.category', $item->slug)); ?>"><?php echo e($item->title); ?></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="py-2">
        <div class="container">
            <div class="info-nav text-center text-muted">
                <a href="<?php echo e(route('l.info', 'tentang-kami')); ?>">Tentang kami</a>
                <a href="<?php echo e(route('l.info', 'ketentuan')); ?>">Term & condition</a>
                <a href="<?php echo e(route('l.info', 'kebijakan')); ?>">Privacy policy</a>
                <a href="<?php echo e(route('l.info', 'iklan')); ?>">Iklan</a>
                <a href="<?php echo e(route('l.contact')); ?>">Hubungi kami</a>
            </div>
        </div>
    </div>
    <div class="bg-light py-3">
        <div class="container">
            <div class="d-block text-center d-lg-flex justify-content-between">
                <span>&copy; <strong><?php echo e($global['setting'][0]->content); ?></strong> 2023. Allrights reserved.</span>
                <span>Developed by <a href="#" target="_BLANK">Inovindo</a></span>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/layouts/app-footer.blade.php ENDPATH**/ ?>