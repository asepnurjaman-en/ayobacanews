
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
        <div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body">
				<div class="row g-3">
					<div class="col-12 col-lg-8">
                        <div class="form-group mb-2">
                            <label for="title" class="form-label mb-1"><?php echo e(__('judul')); ?></label>
							<input type="text" name="title" id="title" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($ad->title ?? old('title')); ?>">
						</div>
                        <div class="form-group mb-2">
                            <label for="url" class="form-label mb-1"><?php echo e(__('url')); ?></label>
                            <input type="url" name="url" id="url" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($ad->url ?? old('url')); ?>">
                        </div>
					</div>
                    <div class="col-12 col-lg-4">
                        <div class="card mb-2">
							<div class="card-body p-3">
								<label class="form-label" for="upload-file"><?php echo e(Str::title('gambar iklan')); ?></label>
								<div class="btn-group d-flex justify-content-between">
									<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
										<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
										<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
									</label>
									<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
										<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="image" readonly>
								<div id="thumbail-preview" class="mb-2">
									<?php if($data['form']['class']=='form-update'): ?>
									<div>
										<div class="item-image">
											<?php echo image(src:url('storage/sm/'.$ad->file), alt:$ad->file); ?>

											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4><?php echo e(Str::title($ad->title)); ?></h4>
												<input type="hidden" name="file" value="<?php echo e($ad->file); ?>">
											</div>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
                    </div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('node_modules/select2/dist/js/select2.min.js')); ?>" type="text/javascript"></script>
<?php echo $__env->make('layouts.panel.storage-modal', ['mode'=>'single'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/ad/form.blade.php ENDPATH**/ ?>