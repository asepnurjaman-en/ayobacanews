
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-3">
							<label for="title" class="form-label mb-1"><?php echo e(__('nama')); ?></label>
							<input type="text" name="title" id="title" class="form-control form-control-lg counting-input" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($strbox->title ?? old('title')); ?>" maxlength="110">
							<ul class="list-unstyled small">
								<li><span class="counting fw-bold"><?php echo e(strlen($strbox->title ?? null)); ?></span>/110</li>
							</ul>
						</div>
					</div>
					<div class="col-12 col-md-5">
						<div class="card mb-3">
							<div class="card-body p-0">
								<?php if($strbox->file_type=='image'): ?>
								<?php echo image(src:url('storage/sm/'.$strbox->file), alt:$strbox->file, class:['img-fluid', 'rounded']); ?>									
								<?php elseif($strbox->file_type=='video'): ?>
								<?php echo video(src:url('storage/'.$strbox->file)); ?>

								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-12 col-md-6"></div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/storage/form.blade.php ENDPATH**/ ?>