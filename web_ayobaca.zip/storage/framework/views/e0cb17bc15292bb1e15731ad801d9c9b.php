
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	<div class="container-fluid flex-grow-1 container-p-y position-relative">
		<div class="card">
			<div class="card-body p-2">
				<form action="<?php echo e($data['form']['action']); ?>" class="<?php echo e($data['form']['class']); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group mb-2">
						<input type="file" name="file" id="file" class="dropify" accept="image/png, image/jpeg">
					</div>
					<div class="form-group input-group mb-2">
						<input type="text" name="title" id="title" class="form-control dropify-title" placeholder="Beri judul">
						<button type="submit" class="btn btn-primary dont-fixit">
							<i class="bx bx-upload"></i>
							<span><?php echo e(Str::title('unggah')); ?></span>
						</button>
					</div>
				</form>
			</div>
			<div class="card-header p-2">
				<form action="<?php echo e($data['delete']['action']); ?>" method="post" class="form-delete my-3 mb-0" data-message="<?php echo e($data['delete']['message']); ?>">
					<?php echo method_field('DELETE'); ?>
					<input type="hidden" name="id_delete" value>
					<button type="submit" class="btn btn-danger" disabled>
						<i class="bx bx-trash"></i>
						<span><?php echo e(ucfirst('hapus')); ?></span>
						<b></b>
					</button>
				</form>
			</div>
			<div class="card-body p-0">
				<table class="dataTables" data-list="<?php echo e(route('home.storage-list')); ?>">
					<thead>
						<tr>
							<th><i class="bx bx-cog"></i></th>
							<th></th>
							<th></th>
							<th></th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/@fancyapps/fancybox/dist/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/dropify/dist/css/dropify.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/@fancyapps/fancybox/dist/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('node_modules/dropify/dist/js/dropify.min.js')); ?>"></script>
<script>
	$("[data-fancybox=preview]").fancybox();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/storage/index.blade.php ENDPATH**/ ?>