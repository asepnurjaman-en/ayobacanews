
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="form-group d-flex justify-content-between mt-3">
        <button type="button" class="btn-back btn btn-outline-secondary">
            <i class="bx bx-chevron-left"></i>
            <span><?php echo e(Str::title('kembali')); ?></span>
        </button>
    </div>
    <div class="card border-0 my-3">
        <h5 class="card-header">Kelola iklan</h5>
        <div class="card-body">
            <div class="row g-w">
                <div class="col-lg-6">
                    <div class="list-group">
                        <a href="<?php echo e(route('article.ad.tp', 'home-ad')); ?>" class="list-group-item list-group-item-action">Beranda</a>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('article-category.ad', $item->id)); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            <?php echo e($item->title); ?>

                            <span class="badge bg-secondary"><?php echo e($item->articles_count); ?> Berita</span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('article.ad.tp', 'contact-ad')); ?>" class="list-group-item list-group-item-action">Kontak</a>
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/ad/show.blade.php ENDPATH**/ ?>