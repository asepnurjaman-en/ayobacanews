
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	<div class="container-fluid flex-grow-1 container-p-y position-relative">
		<ul class="nav nav-pills flex-column flex-md-row mb-3">
			<li class="nav-item">
				<a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> <?php echo e(Str::title('akun saya')); ?></a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(route('setting.password')); ?>"><i class="bx bx-lock me-1"></i> <?php echo e(Str::title('kata sandi')); ?></a>
			</li>
		</ul>
		<div class="card mb-4">
			<h5 class="card-header">
				<i class="bx bxs-user"></i>
				<span><?php echo e(Str::title($data['title'])); ?></span>
			</h5>
			<div class="card-body">
				<form action="<?php echo e($data['form']['action']); ?>" method="POST" class="<?php echo e($data['form']['class']); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PATCH'); ?>
					<div class="row">
						<div class="mb-3 col-md-6">
							<label for="name" class="form-label">nama</label>
							<input class="form-control" type="text" id="name" name="name" value="<?php echo e(Auth::user()->name); ?>" required autofocus>
						</div>
						<div class="mb-3 col-md-6">
							<label for="email" class="form-label">e-mail</label>
							<input class="form-control" type="email" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>" placeholder="isi disini" required>
						</div>
					</div>
					<div class="mt-2">
						<button type="submit" class="btn btn-primary me-2">
							<i class="bx bx-save"></i>
							<span>Simpan</span>
						</button>
						<button type="reset" class="btn btn-outline-secondary">
							<i class="bx bx-reset"></i>
							<span>Batal</span>
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/setting/account.blade.php ENDPATH**/ ?>