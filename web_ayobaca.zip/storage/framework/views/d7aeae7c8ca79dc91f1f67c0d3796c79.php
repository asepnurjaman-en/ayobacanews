<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="theme-color" content="<?php echo e($global['setting'][3]->content); ?>">
    <meta name="keywords" content="<?php echo e($global['setting'][5]->content); ?>">
    <?php echo $__env->yieldPushContent('meta'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/layouts/app.blade.php ENDPATH**/ ?>