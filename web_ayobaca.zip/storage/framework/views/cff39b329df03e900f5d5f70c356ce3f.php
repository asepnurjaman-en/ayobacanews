
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PATCH'); ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row g-3">
					<?php $__empty_1 = true; $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="col-12 col-md-6">
						<div class="link-external_form shadow rounded <?php echo e($item->brand); ?> p-1">
							<div class="d-flex justify-content-between py-2 px-3">
								<span>
									<i class="<?php echo e($item->icon); ?>"></i>
									<?php echo e(Str::title($item->brand)); ?>

								</span>
								<div class="form-check form-switch">
									<input class="form-check-input change-input-status change-input-edited" data-edit="<?php echo e($item->brand.$item->id); ?>" type="checkbox" name="active_<?php echo e($item->brand.$item->id); ?>" data-brand="<?php echo e($item->brand.$item->id); ?>" value="true" <?php echo e(($item->actived=='1') ? 'checked' : null); ?>>
								</div>
							</div>
							<div class="input-group input-group-merge input-group-<?php echo e($item->brand.$item->id); ?> <?php echo e(($item->actived=='0') ? 'disabled' : null); ?>">
								<div class="input-group-text">
									<i class="bx bx-<?php echo e(($item->actived=='0') ? 'unlink' : 'link-alt'); ?>"></i>
								</div>
								<input type="url" name="url_<?php echo e($item->brand.$item->id); ?>" id="url-<?php echo e($item->brand.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->brand.$item->id); ?>" value="<?php echo e($item->url); ?>" data-edit="<?php echo e($item->brand.$item->id); ?>" placeholder="isi url disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
							</div>
							<input type="radio" name="edit_<?php echo e($item->brand.$item->id); ?>" id="edit-<?php echo e($item->brand.$item->id); ?>" value="true">
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/links/social.blade.php ENDPATH**/ ?>