
<?php $__env->startSection('title', 'Kontak | '.Str::title($global['setting'][0]->content)); ?>
<?php $__env->startSection('content'); ?>
<section class="bg-white py-2">
	<div class="container">
		<div class="ayobaca-title">
			<h1>
				<span>Kontak</span>
			</h1>
		</div>
		<div class="row g-2 mb-2">
			<div class="col-lg-8">
				<div class="bg-white rounded-1 shadow-sm p-2 mb-2">
					<label for="address">
						<i class="bx bx-map-alt"></i>
						<?php echo e($global['contact'][0]->title); ?>

					</label>
					<address id="address" class="bg-light rounded-1 p-2 mb-0"><?php echo e($global['contact'][0]->content); ?></address>
				</div>
				<div class="bg-white rounded-1 shadow-sm p-2 mb-2">
					<label for="email">
						<i class="bx bx-phone"></i>
						Telepon
					</label>
					<div class="row">
						<?php $__currentLoopData = $global['contact'][3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4">
							<a href="#" class="contact-block rounded-1 p-2">
								<span><?php echo e($item->title); ?></span>
								<?php echo e($item->content); ?>

							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="bg-white rounded-1 shadow-sm p-2 mb-2">
					<label for="email">
						<i class="bx bxl-whatsapp"></i>
						Whatsapp
					</label>
					<div class="row">
						<?php $__currentLoopData = $global['contact'][4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4">
							<a href="#" class="contact-block rounded-1 p-2">
								<span><?php echo e($item->title); ?></span>
								<?php echo e($item->content); ?>

							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="bg-white rounded-1 shadow-sm p-2 mb-2">
					<label for="email">
						<i class="bx bx-envelope"></i>
						Email
					</label>
					<div class="row">
						<?php $__currentLoopData = $global['contact'][2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4">
							<a href="#" class="contact-block rounded-1 p-2">
								<span><?php echo e($item->title); ?></span>
								<?php echo e($item->content); ?>

							</a>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="top-stick">
					<div class="ad ad-md" data-url="<?php echo e((!empty($ad_1)) ? $ad_1->url : '#'); ?>">
						<?php if(!empty($ad_1)): ?>
						<img src="<?php echo e(url('storage/'.$ad_1->file)); ?>" alt="<?php echo e($ad_1->url); ?>">
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="row g-2">
			<div class="col-lg-8">
				<?php if($global['contact'][1]->content!='no-map'): ?>
				<div class="ayobaca-map bg-white rounded-1 shadow-sm">
					<?php echo $global['contact'][1]->content; ?>

					<b><?php echo e($global['contact'][1]->title); ?></b>
				</div>
				<?php endif; ?>
			</div>
			<div class="col-lg-4">
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_2)) ? $ad_2->url : '#'); ?>">
					<?php if(!empty($ad_2)): ?>
					<img src="<?php echo e(url('storage/'.$ad_2->file)); ?>" alt="<?php echo e($ad_2->url); ?>">
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('running-text'); ?>
<?php echo $__env->make('layouts.component', ['type'=>'running-text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="og:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="og:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="twitter:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="twitter:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="twitter:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/contact.blade.php ENDPATH**/ ?>