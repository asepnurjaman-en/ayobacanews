
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-12">
            <div class="my-3 mb-0">
				<button type="button" class="btn-back btn btn-outline-secondary">
                    <i class="bx bx-chevron-left"></i>
                    <span><?php echo e(Str::title('kembali')); ?></span>
                </button>
			</div>
			<div class="card border-0 my-3">
                <div class="card-header d-flex justify-content-between flex-column flex-md-row p-3">
                    <div class="d-flex flex-column">
                        <span class="fs-5"><b><?php echo e($activity->subject_type[2]); ?></b> <?php echo e(Str::title($activity->event)); ?>.</span>
                        <span>by <b class="text-primary"><?php echo e($causer->name); ?></b></span>
                    </div>
                    <div>
                        <span>at <b><?php echo e($activity->created_at); ?></b></span>
                    </div>
                </div>
				<div class="card-body p-3">
                    <?php if($activity->event=='updated'): ?>                        
                    <div class="log-activity horizonbar d-flex align-items-center justify-content-between flex-column flex-md-row">
                        <div class="bg-light border border-2 border-warning p-3">
                            <?php $__currentLoopData = json_decode($activity->properties, true)['old']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <code><?php echo e(Str::upper($key)); ?></code>
                                <?php if($key=='file'): ?>
                                <div class="p-1"><?php echo anchor(text:"<i class=\"bx bx-search me-1\"></i> Tinjau", class:['btn', 'btn-secondary', 'btn-sm'], data:['fancybox'=>'preview'], href:url('storage/'.$item)); ?></div>
                                <?php elseif($key=='content'): ?>
                                    <?php if(strlen($item)<1000): ?>
                                    <div class="px-1"><i class="bx bx-subdirectory-right me-1"></i><?php echo e($item); ?></div>                                    
                                    <?php else: ?>
                                    <div class="fst-italic fw-light"><i class="bx bx-error-circle text-danger me-1"></i><?php echo e(__('cannot be loaded')); ?></div>
                                    <?php endif; ?>
                                <?php else: ?>
                                <div class="px-1 break-all"><i class="bx bx-subdirectory-right me-1"></i><?php echo e($item); ?></div>                                    
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <span><i class="bx bx-right-arrow-alt my-2"></i></span>
                        <div class="bg-light border border-2 border-success p-3">
                            <?php $__currentLoopData = json_decode($activity->properties, true)['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <code><?php echo e(Str::upper($key)); ?></code>
                                <?php if($key=='file'): ?>
                                <div class="p-1">
                                    <?php echo anchor(text:"<i class=\"bx bx-search me-1\"></i> Tinjau", class:['btn', (json_decode($activity->properties, true)['old'][$key]==$item) ? 'btn-secondary' : 'btn-warning', 'btn-sm'], data:['fancybox'=>'preview'], href:url('storage/'.$item)); ?>

                                    
                                </div>
                                <?php elseif($key=='content'): ?>
                                    <?php if(strlen($item)<1000): ?>
                                    <div class="px-1"><i class="bx bx-subdirectory-right me-1"></i><?php echo (json_decode($activity->properties, true)['old'][$key]==$item) ? $item : "<mark>{$item}</mark>"; ?></div>                                    
                                    <?php else: ?>
                                    <div class="fst-italic fw-light"><i class="bx bx-error-circle text-danger me-1"></i><?php echo e(__('cannot be loaded')); ?></div>
                                    <?php endif; ?>
                                <?php else: ?>
                                <div class="px-1 break-all"><i class="bx bx-subdirectory-right me-1"></i><?php echo (json_decode($activity->properties, true)['old'][$key]==$item) ? $item : "<mark>{$item}</mark>"; ?></div>                                    
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php elseif($activity->event=='created'): ?>
                    <div>
                        <div class="bg-light border border-2 border-success p-3">
                            <?php $__currentLoopData = json_decode($activity->properties, true)['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <code><?php echo e(Str::upper($key)); ?></code>
                                <?php if($key=='file'): ?>
                                <div class="p-1"><?php echo anchor(text:"<i class=\"bx bx-search me-1\"></i> Tinjau", class:['btn', 'btn-secondary', 'btn-sm'], data:['fancybox'=>'preview'], href:url('storage/'.$item)); ?></div>
                                <?php elseif($key=='content'): ?>
                                    <?php if(strlen($item)<1000): ?>
                                    <div class="px-1"><i class="bx bx-subdirectory-right me-1"></i><?php echo e($item); ?></div>                                    
                                    <?php else: ?>
                                    <div class="fst-italic fw-light"><i class="bx bx-error-circle text-danger me-1"></i><?php echo e(__('cannot be loaded')); ?></div>
                                    <?php endif; ?>
                                <?php else: ?>
                                <div class="px-1 break-all"><i class="bx bx-subdirectory-right me-1"></i><?php echo e($item); ?></div>                                    
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/@fancyapps/fancybox/dist/jquery.fancybox.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/@fancyapps/fancybox/dist/jquery.fancybox.min.js')); ?>"></script>
<script>
	$("[data-fancybox=preview]").fancybox();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/setting/log-detail.blade.php ENDPATH**/ ?>