<?php $__env->startSection('title', Str::title($global['setting'][0]->content)); ?>
<?php $__env->startSection('content'); ?>
<section>
    <div class="container">
        <?php echo anchor(text:Str::title('masuk'), href:'/panel'); ?>

        <hr>
        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <?php echo e(Str::title('keluar')); ?>

        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
		</form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="og:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="og:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="twitter:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="twitter:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="twitter:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/home.blade.php ENDPATH**/ ?>