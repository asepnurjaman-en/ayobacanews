<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	
	
	
	
	
	<?php echo $__env->yieldPushContent('style'); ?>
	
	
	
	<link rel="shortcut icon" href="<?php echo e(url('sneat/img/favicon.png')); ?>" type="image/x-icon">
	
	
	<link rel="stylesheet" href="<?php echo e(asset('build/assets/sneat-af113d55.css')); ?>">
</head>
<body>
	<div class="layout-wrapper layout-content-navbar">
		<div class="layout-container">
			<?php echo $__env->make('layouts.editor.app-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="layout-page">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</div>
		<div class="layout-overlay layout-menu-toggle"></div>
	</div>
	
	<script src="<?php echo e(asset('node_modules/jquery/dist/jquery.min.js')); ?>"></script>
	
	<script src="<?php echo e(asset('node_modules/@popperjs/core/dist/umd/popper.min.js')); ?>"></script>
	
	
	<?php echo $__env->yieldPushContent('script'); ?>
	
	<script src="<?php echo e(asset('build/assets/sneat-69b35c46.js')); ?>" type="module"></script>
	
	
	
</body>
</html><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/layouts/editor/app.blade.php ENDPATH**/ ?>