<?php
	$menu = [
		[
			'title' => 'Dasbor',
			'menu'	=> [
				[
					'id'	=> ['home.dashboard'],
					'title'	=> 'Dasbor',
					'url'	=> route('home.dashboard'),
					'icon'	=> 'bx bxs-dashboard',
					'sub'	=> []
				],
				[
					'id'	=> ['home.storage', 'home.storage-edit'],
					'title'	=> 'Pustaka',
					'url'	=> route('home.storage'),
					'icon'	=> 'bx bxs-grid',
					'sub'	=> [
						[
							'id'	=> [],
							'title'	=> 'Pustaka Gambar',
							'url'	=> route('home.storage', 'image')
						],
						[
							'id'	=> [],
							'title'	=> 'Pustaka Video',
							'url'	=> route('home.storage', 'video')
						]
					]
				]
			]
		],
		[
			'title'	=> 'Menu',
			'menu'	=> [
				[
					'id'	=> ['profile.index'],
					'title'	=> 'Profil',
					'url'	=> route('profile.index'),
					'icon'	=> 'bx bx-user',
					'sub'	=> []
				],
				[
					'id'	=> ['article.index', 'article.create', 'article.edit', 'article-category.index', 'article-category.create', 'article-category.edit'],
					'title'	=> 'Artikel',
					'url'	=> route('article.index'),
					'icon'	=> 'bx bx-news',
					'sub'	=> [
						[
							'id'	=> ['article.index', 'article.create', 'article.edit'],
							'title'	=> 'Artikel',
							'url'	=> route('article.index')
						],
						[
							'id'	=> ['article-category.index', 'article-category.create', 'article-category.edit'],
							'title'	=> 'Label Artikel',
							'url'	=> route('article-category.index')
						],
					]
				],
				[
					'id'	=> ['gallery-photo.index', 'gallery-photo.create', 'gallery-photo.edit', 'gallery-photo.edit-files', 'gallery-video.index', 'gallery-video.create', 'gallery-video.edit'],
					'title'	=> 'Galeri',
					'url'	=> route('gallery-photo.index'),
					'icon'	=> 'bx bx-images',
					'sub'	=> [
						[
							'id'	=> ['gallery-photo.index', 'gallery-photo.create', 'gallery-photo.edit', 'gallery-photo.edit-files'],
							'title'	=> 'Foto',
							'url'	=> route('gallery-photo.index')
						],
						[
							'id'	=> ['gallery-video.index', 'gallery-video.create', 'gallery-video.edit'],
							'title'	=> 'Video',
							'url'	=> route('gallery-video.index')
						],
					]
				],
				[
					'id'	=> ['contact.index'],
					'title'	=> 'Kontak',
					'url'	=> route('contact.index', 'address'),
					'icon'	=> 'bx bx-id-card',
					'sub'	=> []
				],
			]
		],
		[
			'title'	=> 'Produk',
			'menu'	=> [
				[
					'id'	=> ['product.index', 'product.create', 'product.edit', 'product-catalog.index', 'product-catalog.create', 'product-catalog.edit'],
					'title'	=> 'Produk',
					'url'	=> route('product.index'),
					'icon'	=> 'bx bx-box',
					'sub'	=> [
						[
							'id'	=> ['product.index', 'product.create', 'product.edit'],
							'title'	=> 'Produk',
							'url'	=> route('product.index')
						],
						[
							'id'	=> ['product-catalog.index', 'product-catalog.create', 'product-catalog.edit'],
							'title'	=> 'Katalog',
							'url'	=> route('product-catalog.index')
						],
					]
				],
				[
					'id'	=> ['product-supplier.index', 'product-supplier.create', 'product-supplier.edit'],
					'title'	=> 'Penyuplai',
					'url'	=> route('product-supplier.index'),
					'icon'	=> 'bx bx-layer',
					'sub'	=> []
				],
				[
					'id'	=> ['product-stock.create'],
					'title'	=> 'Suplai Stok',
					'url'	=> route('product-stock.create'),
					'icon'	=> 'bx bx-layer-plus',
					'sub'	=> []
				]
			]
		],
		[
			'title'	=> 'Layanan',
			'menu'	=> [
				[
					'id'	=> ['service.index', 'service.create', 'service.edit', 'service-catalog.index', 'service-catalog.create', 'service-catalog.edit'],
					'title'	=> 'Layanan',
					'url'	=> route('service.index'),
					'icon'	=> 'bx bx-wrench',
					'sub'	=> [
						[
							'id'	=> ['service.index', 'service.create', 'service.edit'],
							'title'	=> 'Layanan',
							'url'	=> route('service.index')
						],
						[
							'id'	=> ['service-catalog.index', 'service-catalog.create', 'service-catalog.edit'],
							'title'	=> 'Katalog',
							'url'	=> route('service-catalog.index')
						],
					]
				],
			]
		],
		[
			'title'	=> 'Member',
			'menu'	=> [
				[
					'id'	=> ['member.index', 'member.create', 'member.edit'],
					'title'	=> 'Member',
					'url'	=> route('member.index'),
					'icon'	=> 'bx bx-user-circle',
					'sub'	=> []
				]
			]
		],
		[
			'title'	=> 'Timbal balik',
			'menu'	=> [
				[
					'id'	=> ['feedback.index', 'feedback.show'],
					'title'	=> 'Feedback',
					'url'	=> route('feedback.index'),
					'icon'	=> 'bx bx-comment-dots',
					'sub'	=> []
				],
				[
					'id'	=> ['checkout.index', 'feedback.show'],
					'title'	=> 'Shopping Checkout',
					'url'	=> route('checkout.index'),
					'icon'	=> 'bx bx-cart-alt',
					'sub'	=> []
				]
			]
		],
		[
			'title'	=> 'Lainnya',
			'menu'	=> [
				[
					'id'	=> ['carousel.index', 'carousel.create', 'carousel.edit'],
					'title'	=> 'Carousel',
					'url'	=> route('carousel.index'),
					'icon'	=> 'bx bxs-carousel',
					'sub'	=> []
				],
				[
					'id'	=> ['social.index', 'ecommerce.index'],
					'title'	=> 'Sosial Media',
					'url'	=> route('social.index'),
					'icon'	=> 'bx bx-message-square',
					'sub'	=> [
						[
							'id'	=> ['social.index'],
							'title'	=> 'Sosial Media',
							'url'	=> route('social.index')
						],
						[
							'id'	=> ['ecommerce.index'],
							'title'	=> 'Toko Online',
							'url'	=> route('ecommerce.index')
						],
					]
				],
				[
					'id'	=> ['testimony.index', 'testimony.create', 'testimony.edit'],
					'title'	=> 'Testimoni',
					'url'	=> route('testimony.index'),
					'icon'	=> 'bx bx-chat',
					'sub'	=> []
				]
			]
		],
	]
?>
<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
	<div class="app-brand py-2">
		<a class="app-brand-link">
			<span class="app-brand-logo">
				<i class="bx bx-customize text-primary fs-1"></i>
			</span>
			<span class="app-brand-text menu-text fw-bolder ms-2">
				<?php if(Auth::user()->role=='admin'): ?>
				<?php echo e(Str::title('panel')); ?>

				<?php elseif(Auth::user()->role=='developer'): ?>
				<span class="badge badge-tag warning" data-tag="dev"><?php echo e(Str::title('panel')); ?></span>
				<?php endif; ?>
			</span>
		</a>
		<a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
			<i class="bx bx-chevron-left bx-sm align-middle"></i>
		</a>
	</div>
	<div class="menu-inner-shadow"></div>
	<ul class="menu-inner py-1">
		<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"><?php echo e($nav['title']); ?></span>
		</li>
		<?php if(count($nav['menu']) > 0): ?>
		<?php $__currentLoopData = $nav['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if(count($nav_link['sub']) > 0): ?>
		<li class="menu-item <?php echo e((in_array(Route::currentRouteName(), $nav_link['id'])) ? 'active open' : null); ?>">
			<a href="javascript:void(0);" class="menu-link menu-toggle text-decoration-none">
				<i class="menu-icon tf-icons <?php echo e($nav_link['icon']); ?>"></i>
				<div data-i18n="<?php echo e($nav_link['title']); ?>"><?php echo e($nav_link['title']); ?></div>
			</a>
			<ul class="menu-sub">
				<?php $__currentLoopData = $nav_link['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="menu-item <?php echo e((in_array(Route::currentRouteName(), $sub_link['id'])) ? 'active open' : null); ?>">
					<a href="<?php echo e($sub_link['url']); ?>" class="menu-link text-decoration-none">
						<div data-i18n="<?php echo e($sub_link['title']); ?>"><?php echo e($sub_link['title']); ?></div>
					</a>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</li>
		<?php else: ?>
		<li class="menu-item <?php echo e((in_array(Route::currentRouteName(), $nav_link['id'])) ? 'active' : null); ?>">
			<a href="<?php echo e($nav_link['url']); ?>" class="menu-link text-decoration-none">
				<i class="menu-icon tf-icons <?php echo e($nav_link['icon']); ?>"></i>
				<div data-i18n="<?php echo e($nav_link['title']); ?>"><?php echo e($nav_link['title']); ?></div>
			</a>
		</li>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"></span>
		</li>
		<li class="menu-item">
			<a href="<?php echo e(route('logout')); ?>" class="menu-link text-decoration-none text-white bg-danger" 
			onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
				<i class="menu-icon tf-icons bx bx-exit"></i>
				<div data-i18n="Logout"><?php echo e(__('Logout')); ?></div>
			</a>
		</li>
	</ul>
</aside><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/layouts/panel/app-menu.blade.php ENDPATH**/ ?>