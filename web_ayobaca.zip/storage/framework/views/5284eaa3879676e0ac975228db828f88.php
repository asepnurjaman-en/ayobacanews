<?php $__env->startSection('title', Str::title($global['setting'][0]->content)); ?>
<?php $__env->startSection('content'); ?>
<section class="py-2">
	<div class="container">
		
		<div class="row g-2 mb-2">
			<div class="col-lg-9">
				<div class="row flex-lg-row-reverse g-2">
					<div class="col-lg-8">
						<?php $__empty_1 = true; $__currentLoopData = $category[0]->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="news-box-lg bg-white overflow-hidden shadow-sm rounded-1">
							<div class="image skeleton">
								<img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid rounded-top d-none" loading="lazy">
								<label class="ayobaca-label rounded-1">
									<i style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$item->article_category->color) ?>"></i>
									<span><?php echo e($item->article_category->title); ?></span>
								</label>
							</div>
							<div class="desc p-3">
								<h2>
									<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
								</h2>
								<div class="py-1 small text-muted">
									<span class="me-2"><?php echo e(date_stat($item->datetime)); ?></span>
									<span><?php echo e($item->author); ?></span>
								</div>
								<blockquote><?php echo e($item->description); ?></blockquote>
								<div class="button">
									<a href="<?php echo e(route('l.news', $item->slug)); ?>">
										<span>baca selengkapnya</span>
										<i class="icon-arrow-down"></i>
									</a>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="empty">Segera rilis</div>
						<?php endif; ?>
						<div class="top-stick">
							<div class="ad ad-md" data-url="<?php echo e((!empty($ad_1)) ? $ad_1->url : '#'); ?>">
								<?php if(!empty($ad_1)): ?>
								<img src="<?php echo e(url('storage/'.$ad_1->file)); ?>" alt="<?php echo e($ad_1->url); ?>">
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<?php echo $__env->make('layouts.component', ['type'=>'trending'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="weather-info text-white d-flex align-items-center rounded shadow-sm p-3 mb-2">
					<div class="weather-info-animation">
						<canvas id="animated-icon" width="90" height="90"></canvas>
					</div>
					<div class="weather-info-text px-3">
						<small>Cuaca hari ini di </small>
						<span class="location fs-5"></span>
						<div class="temperature fs-4 fw-bolder">
							<span class="temp-celsius">°C</span>
						</div>
					</div>
				</div>
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_2)) ? $ad_2->url : '#'); ?>">
					<?php if(!empty($ad_2)): ?>
					<img src="<?php echo e(url('storage/'.$ad_2->file)); ?>" alt="<?php echo e($ad_2->url); ?>">
					<?php endif; ?>
				</div>
				<?php echo $__env->make('layouts.component', ['type'=>'highlight'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</div>
		
		<div class="row g-2">
			
			<div class="col-lg-3">
				<?php $__empty_1 = true; $__currentLoopData = $category[1]->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="news-box-md bg-white shadow-sm rounded-sm mb-2">
					<div class="image skeleton">
						<img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/sm/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid rounded-top d-none" loading="lazy">
						<label class="ayobaca-label rounded-1">
							<i style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$item->article_category->color) ?>"></i>
							<span><?php echo e($item->article_category->title); ?></span>
						</label>
					</div>
					<div class="desc p-2">
						<h3>
							<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
						</h3>
					</div>
					<div class="d-flex justify-content-between p-2 small text-muted">
						<span><?php echo e(date_stat($item->datetime)); ?></span>
						<span><?php echo e($item->author); ?></span>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<div class="empty">Segera rilis</div>
				<?php endif; ?>
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_3)) ? $ad_3->url : '#'); ?>">
					<?php if(!empty($ad_3)): ?>
					<img src="<?php echo e(url('storage/'.$ad_3->file)); ?>" alt="<?php echo e($ad_3->url); ?>">
					<?php endif; ?>
				</div>
				<div class="top-stick">
					<div class="bg-white shadow-sm rounded-1 mb-2">
						<?php $__empty_1 = true; $__currentLoopData = $category[1]->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="news-box-sm p-2 lh-sm border-bottom">
							<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
							<div class="d-flex justify-content-between pt-2 small text-muted">
								<div>
									<span class="fw-bold"><?php echo e($item->article_category->title); ?> &dash;</span>
									<span><?php echo e(date_stat($item->datetime)); ?></span>
								</div>
								<span><?php echo e($item->author); ?></span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="empty">Segera rilis</div>
						<?php endif; ?>
					</div>
					<a href="<?php echo e(route('l.category', $category[1]->slug)); ?>" class="d-flex align-items-center justify-content-between text-decoration-none redBaca text-white rounded-1 shadow-sm px-2 py-1">
						<span>Lihat semua</span>
						<i class="icon-arrow-right"></i>
					</a>
				</div>
			</div>
			
			
			<div class="col-lg-3">
				<?php $__empty_1 = true; $__currentLoopData = $category[2]->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="news-box-md bg-white shadow-sm rounded-sm mb-2 mb-lg-0">
					<div class="image skeleton">
						<img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/sm/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid rounded-top d-none" loading="lazy">
						<label class="ayobaca-label rounded-1">
							<i style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$item->article_category->color) ?>"></i>
							<span><?php echo e($item->article_category->title); ?></span>
						</label>
					</div>
					<div class="desc p-2">
						<h3>
							<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
						</h3>
					</div>
					<div class="d-flex justify-content-between p-2 small text-muted">
						<span><?php echo e(date_stat($item->datetime)); ?></span>
						<span><?php echo e($item->author); ?></span>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<div class="empty">Segera rilis</div>
				<?php endif; ?>
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_4)) ? $ad_4->url : '#'); ?>">
					<?php if(!empty($ad_4)): ?>
					<img src="<?php echo e(url('storage/'.$ad_4->file)); ?>" alt="<?php echo e($ad_4->url); ?>">
					<?php endif; ?>
				</div>
				<div class="top-stick">
					<div class="bg-white shadow-sm rounded-1 mb-2 mb-lg-0">
						<?php $__empty_1 = true; $__currentLoopData = $category[2]->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="news-box-sm p-2 lh-sm border-bottom">
							<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
							<div class="d-flex justify-content-between pt-2 small text-muted">
								<div>
									<span class="fw-bold"><?php echo e($item->article_category->title); ?> &dash;</span>
									<span><?php echo e(date_stat($item->datetime)); ?></span>
								</div>
								<span><?php echo e($item->author); ?></span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="empty">Segera rilis</div>
						<?php endif; ?>
					</div>
					<a href="<?php echo e(route('l.category', $category[2]->slug)); ?>" class="d-flex align-items-center justify-content-between text-decoration-none redBaca text-white rounded-1 shadow-sm px-2 py-1">
						<span>Lihat semua</span>
						<i class="icon-arrow-right"></i>
					</a>
				</div>
			</div>
			<div class="col-lg-3">
				<?php $__empty_1 = true; $__currentLoopData = $category[3]->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="news-box-md bg-white shadow-sm rounded-sm mb-2">
					<div class="image skeleton">
						<img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/sm/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid rounded-top d-none" loading="lazy">
						<label class="ayobaca-label rounded-1">
							<i style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$item->article_category->color) ?>"></i>
							<span><?php echo e($item->article_category->title); ?></span>
						</label>
					</div>
					<div class="desc p-2">
						<h3>
							<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
						</h3>
					</div>
					<div class="d-flex justify-content-between p-2 small text-muted">
						<span><?php echo e(date_stat($item->datetime)); ?></span>
						<span><?php echo e($item->author); ?></span>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<div class="empty">Segera rilis</div>
				<?php endif; ?>
				<div class="top-stick">
					<div class="bg-white shadow-sm rounded-1 mb-2">
						<?php $__empty_1 = true; $__currentLoopData = $category[3]->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="news-box-sm p-2 lh-sm border-bottom">
							<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
							<div class="d-flex justify-content-between pt-2 small text-muted">
								<div>
									<span class="fw-bold"><?php echo e($item->article_category->title); ?> &dash;</span>
									<span><?php echo e(date_stat($item->datetime)); ?></span>
								</div>
								<span><?php echo e($item->author); ?></span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="empty">Segera rilis</div>
						<?php endif; ?>
					</div>
					<a href="<?php echo e(route('l.category', $category[3]->slug)); ?>" class="d-flex align-items-center justify-content-between text-decoration-none redBaca text-white rounded-1 shadow-sm px-2 py-1">
						<span>Lihat semua</span>
						<i class="icon-arrow-right"></i>
					</a>
				</div>
			</div>
			
			
			<div class="col-lg-3">
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_5)) ? $ad_5->url : '#'); ?>">
					<?php if(!empty($ad_5)): ?>
					<img src="<?php echo e(url('storage/'.$ad_5->file)); ?>" alt="<?php echo e($ad_5->url); ?>">
					<?php endif; ?>
				</div>
				<div>
					<?php $__empty_1 = true; $__currentLoopData = $category[4]->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="news-box-md bg-white shadow-sm rounded-sm mb-2">
						<div class="desc p-2">
							<h3>
								<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
							</h3>
						</div>
						<div class="d-flex justify-content-between px-2 small text-muted">
							<span><?php echo e(date_stat($item->datetime)); ?></span>
							<span><?php echo e($item->author); ?></span>
						</div>
						<div class="image skeleton">
							<img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/sm/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid d-none" loading="lazy">
							<label class="ayobaca-label rounded-1">
								<i style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$item->article_category->color) ?>"></i>
								<span><?php echo e($item->article_category->title); ?></span>
							</label>
						</div>
						<div class="desc p-2">
							<blockquote><?php echo e($item->description); ?></blockquote>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<div class="empty">Segera rilis</div>
					<?php endif; ?>
					<a href="<?php echo e(route('l.category', $category[4]->slug)); ?>" class="d-flex align-items-center justify-content-between text-decoration-none redBaca text-white rounded-1 shadow-sm px-2 py-1">
						<span>Lihat semua</span>
						<i class="icon-arrow-right"></i>
					</a>
				</div>
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_6)) ? $ad_6->url : '#'); ?>">
					<?php if(!empty($ad_6)): ?>
					<img src="<?php echo e(url('storage/'.$ad_6->file)); ?>" alt="<?php echo e($ad_6->url); ?>">
					<?php endif; ?>
				</div>
				<div class="top-stick">
					<?php $__empty_1 = true; $__currentLoopData = $category[4]->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="news-box-md bg-white shadow-sm rounded-sm mb-2">
						<div class="desc p-2">
							<h3>
								<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
							</h3>
						</div>
						<div class="d-flex justify-content-between px-2 small text-muted">
							<span><?php echo e(date_stat($item->datetime)); ?></span>
							<span><?php echo e($item->author); ?></span>
						</div>
						<div class="image skeleton">
							<img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/sm/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid d-none" loading="lazy">
							<label class="ayobaca-label rounded-1">
								<i style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$item->article_category->color) ?>"></i>
								<span><?php echo e($item->article_category->title); ?></span>
							</label>
						</div>
						<div class="desc p-2">
							<blockquote><?php echo e($item->description); ?></blockquote>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<div class="empty">Segera rilis</div>
					<?php endif; ?>
					<a href="<?php echo e(route('l.category', $category[4]->slug)); ?>" class="d-flex align-items-center justify-content-between text-decoration-none redBaca text-white rounded-1 shadow-sm px-2 py-1">
						<span>Lihat semua</span>
						<i class="icon-arrow-right"></i>
					</a>
				</div>
			</div>
			
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('running-text'); ?>
<?php echo $__env->make('layouts.component', ['type'=>'running-text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="og:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="og:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="twitter:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="twitter:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="twitter:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="https://rawgit.com/darkskyapp/skycons/master/skycons.js"></script>
<script>
	var weatherBG = $(".weather-info");
	// inspired by the Design and code by Ayo Isaiah
	//Skycons

	let skycons = new Skycons({color: "#ffffff"});
		skycons.add("animated-icon", Skycons.CLEAR_DAY);
		skycons.play();
	weatherBG.css('background-image', "url('<?php echo e(url('img/weather/CLEAR_DAY.jpg')); ?>')");

	//Some Global variables
	var longitude, latitude, timeHour, timeFull;
	//Function to update weather information

	function updateWeather(json) {
		longitude = json.coord.lon;
		latitude = json.coord.lat;
		//AJAX request
		let geoJSON = $.getJSON("https://secure.geonames.org/timezoneJSON?lat=" + latitude + "&lng=" + longitude + "&username=ayoisaiah").then(function(timezone) {
			var rawTimeZone = JSON.stringify(timezone);
			var parsedTimeZone = JSON.parse(rawTimeZone);
			var dateTime = parsedTimeZone.time;
			timeFull = dateTime.substr(11);
			$(".local-time").html(timeFull); //Update local time
			timeHour = dateTime.substr(-5, 2);
			//Update Weather parameters and location
			$(".weather-condition").html(json.weather[0].description);
			var temp = [
				(json.main.temp - 273.15).toFixed(0) + "°C",
				(1.8 * (json.main.temp - 273.15) + 32).toFixed(0) + "°F"
			];
			$(".temp-celsius").html(temp[0]);
			$(".location").html(json.name);

			//Update Weather animation based on the returned weather description

			var weather = json.weather[0].description;
			if (weather.indexOf("rain") >= 0) {
				skycons.set("animated-icon", Skycons.RAIN);
				weatherBG.css('background-image', "url('<?php echo e(url('img/weather/RAIN.jpg')); ?>')");
			} else if (weather.indexOf("sunny") >= 0) {
				skycons.set("animated-icon", Skycons.CLEAR_DAY);
				weatherBG.css('background-image', "url('<?php echo e(url('img/weather/CLEAR_DAY.jpg')); ?>')");
			} else if (weather.indexOf("clear") >= 0) {
				if (timeHour >= 7 && timeHour < 20) {
					skycons.set("animated-icon", Skycons.CLEAR_DAY);
					weatherBG.css('background-image', "url('<?php echo e(url('img/weather/CLEAR_DAY.jpg')); ?>')");
				} else {
					skycons.set("animated-icon", Skycons.CLEAR_NIGHT);
					weatherBG.css('background-image', "url('<?php echo e(url('img/weather/CLEAR_NIGHT.jpg')); ?>')");
				}
			} else if (weather.indexOf("cloud") >= 0) {
				if (timeHour >= 7 && timeHour < 20) {
					skycons.set("animated-icon", Skycons.PARTLY_CLOUDY_DAY);
					weatherBG.css('background-image', "url('<?php echo e(url('img/weather/PARTLY_CLOUDY_DAY.jpg')); ?>')");
				} else {
					skycons.set("animated-icon", Skycons.PARTLY_CLOUDY_NIGHT);
					weatherBG.css('background-image', "url('<?php echo e(url('img/weather/PARTLY_CLOUDY_NIGHT.jpg')); ?>')");
				}
			} else if (weather.indexOf("thunderstorm") >= 0) {
				skycons.set("animated-icon", Skycons.SLEET);
					weatherBG.css('background-image', "url('<?php echo e(url('img/weather/SLEET.jpg')); ?>')");
			} else if (weather.indexOf("snow") >= 0) {
				skycons.set("animated-icon", Skycons.SNOW);
					weatherBG.css('background-image', "url('<?php echo e(url('img/weather/SNOW.jpg')); ?>')");
			}
		});
	}
	if (navigator.geolocation) {
		window.onload = function() {
			var currentPosition;
			function getCurrentLocation(position) {
				currentPosition = position;
				latitude = currentPosition.coords.latitude;
				longitude = currentPosition.coords.longitude;

				$.getJSON(
					"https://api.openweathermap.org/data/2.5/weather?lat=" + latitude + "&lon=" + longitude + "&APPID=4e5a45260e98e770e7377f516bc22d75",
					function(data) {
						var rawJson = JSON.stringify(data);
						var json = JSON.parse(rawJson);
						updateWeather(json); //Update Weather parameters
					}
				);
			}
			navigator.geolocation.getCurrentPosition(getCurrentLocation);
		};
	} else {
		alert("Geolocation is not supported by your browser, download the latest Chrome or Firefox to use this app");
	}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/home.blade.php ENDPATH**/ ?>