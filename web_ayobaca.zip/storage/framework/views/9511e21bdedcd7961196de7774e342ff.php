
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	<div class="container-fluid flex-grow-1 container-p-y position-relative">
		<ul class="nav nav-pills flex-column flex-md-row mb-3">
            <?php $__currentLoopData = $tablist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
				<a class="nav-link <?php echo e((request()->fullUrl()==$tab['url']) ? 'active' : null); ?>" href="<?php echo e($tab['url']); ?>"><i class="<?php echo e($tab['icon']); ?> me-1"></i> <?php echo e(Str::title($tab['title'])); ?></a>
			</li>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<div class="card mb-4">
			<div class="card-body p-3">
				<form action="<?php echo e($data['form']['action']); ?>" method="POST" class="<?php echo e($data['form']['class']); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PATCH'); ?>
                    <div class="row">
						<div class="mb-3 col-md-6">
							<label for="password" class="form-label"><?php echo e(__('kata sandi baru')); ?></label>
							<input class="form-control" type="password" id="password" name="password" placeholder="isi disini" required>
						</div>
						<div class="mb-3 col-md-6">
							<label for="password-confirmation" class="form-label"><?php echo e(__('konfirmasi kata sandi baru')); ?></label>
							<input class="form-control" type="password" id="password-confirmation" name="password_confirmation" placeholder="isi disini" required>
						</div>
						<div class="mb-3 col-md-6">
							<label for="password-old" class="form-label"><?php echo e(__('kata sandi sebelumnya')); ?></label>
							<input class="form-control" type="password" id="password-old" name="password_old" placeholder="isi disini" required>
						</div>
					</div>
					<div class="mt-2">
						<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
							<i class="bx bx-save"></i>
							<span><?php echo e(Str::title('simpan')); ?></span>
						</button>
						<button type="reset" class="btn btn-outline-secondary">
							<i class="bx bx-reset"></i>
							<span><?php echo e(Str::title('batal')); ?></span>
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/setting/password.blade.php ENDPATH**/ ?>