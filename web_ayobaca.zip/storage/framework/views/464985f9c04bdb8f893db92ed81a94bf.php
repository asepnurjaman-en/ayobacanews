
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="form-group">
			<label for="title" class="form-label mb-1"><?php echo e(__('judul berita')); ?></label>
			<input type="text" name="title" id="title" class="form-control form-control-lg counting-input" placeholder="isi disini" value="<?php echo e($article->title ?? old('title')); ?>" maxlength="110">
			<ul class="list-unstyled small">
				<li><span class="counting fw-bold"><?php echo e(strlen($article->title ?? null)); ?></span>/110</li>
			</ul>
		</div>
		<div class="my-1">
			<div>
				<div class="row g-2">
					<div class="col-12 col-lg-8">
						<div class="sticky-top">
							<textarea name="content" id="content" class="mce"><?php echo e($article->content ?? old('content')); ?></textarea>
						</div>
					</div>
					<div class="col-12 col-lg-4">
						<button type="submit" class="btn btn-primary w-100" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
							<i class="bx bx-save"></i>
							<span><?php echo e(Str::title('simpan')); ?></span>
						</button>
						<div class="card border mt-2 mb-2">
							<div class="card-body p-3">
								<?php $__currentLoopData = ['draft'=>'draft', 'publish'=>'rilis', 'schedule'=>'dijadwalkan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="form-check">
									<input class="form-check-input" type="radio" name="publish" id="<?php echo e($key); ?>" value="<?php echo e($key); ?>" <?php if($article->publish==$key): echo 'checked'; endif; ?>>
									<label class="form-check-label" for="<?php echo e($key); ?>"><?php echo e(Str::title($val)); ?></label>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<div id="scheduled" class="card-body border-top p-3 <?php echo e((!in_array($article->publish, ['schedule'])) ? 'd-none' : null); ?>">
								<input type="date" name="schedule_date" id="schedule_date" class="form-control mb-2" placeholder="isi disini" value="<?php echo e(($data['form']['class']=='form-update' && !empty($article->schedule_time)) ? date('Y-m-d', strtotime($article->schedule_time)) : date('Y-m-d')); ?>">
								<input type="time" name="schedule_time" id="schedule_time" class="form-control" placeholder="isi disini" value="<?php echo e(($data['form']['class']=='form-update' && !empty($article->schedule_time)) ? date('H:i', strtotime($article->schedule_time)) : date('H:i')); ?>">
							</div>
						</div>
						<div class="card border mb-2">
							<div class="card-body p-3">
								<label class="form-label" for="upload-file"><?php echo e(Str::title('thumbnail')); ?></label>
								<div class="btn-group d-flex justify-content-between">
									<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
										<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
										<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
									</label>
									<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
										<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
									</button>
									<button type="button" class="btn btn-outline-danger border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#input-youtube-modal" data-file-type="video">
										<i class="bx bxl-youtube" data-bs-toggle="tooltip" data-bs-original-title="Tautan Youtube" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="<?php echo e($article->file_type ?? old('file_type')); ?>" readonly>
								<div id="thumbail-preview" class="mb-2">
									<?php if($data['form']['class']=='form-update'): ?>
									<div>
										<div class="item-image">
											<?php if($article->file_type=='image'): ?>
											<?php echo image(src:url('storage/sm/'.$article->file), alt:$article->file); ?>

											<?php elseif($article->file_type=='video'): ?>
											<?php echo image(src:url('https://img.youtube.com/vi/'.$article->file.'/hqdefault.jpg'), alt:$article->file_type); ?>

											<?php endif; ?>
											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4><?php echo e(Str::title($article->file_type)); ?></h4>
												<input type="hidden" name="file" value="<?php echo e($article->file); ?>">
											</div>
										</div>
									</div>
									<?php endif; ?>
								</div>
								<textarea name="file_source" id="file_source" class="form-control" placeholder="Keterangan"><?php echo e($article->file_source ?? old('file_source')); ?></textarea>
							</div>
						</div>
						<div id="articleAssets" class="accordion">
							<div class="accordion-item card">
							  	<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_article_category_id" aria-controls="accor_article_category_id" aria-expanded="false">Kategori</button>
							  	</h2>
								<div id="accor_article_category_id" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<select name="article_category_id" id="article_category_id" class="form-control select2 w-100">
											<?php $__empty_1 = true; $__currentLoopData = $article_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
											<option value="<?php echo e($item->id); ?>" <?php echo e(($data['form']['class']=='form-update' && $article->article_category_id==$item->id) ? 'selected' : null); ?>><?php echo e($item->title); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
											<option><?php echo e(__('empty')); ?></option>
											<?php endif; ?>
										</select>
									</div>
								</div>
							</div>
		
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_date" aria-controls="accor_date" aria-expanded="false">Waktu &amp; tanggal</button>
								</h2>
								<div id="accor_date" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<input type="date" name="date" id="date" class="form-control mb-2" placeholder="isi disini" value="<?php echo e(($data['form']['class']=='form-update' && !empty($article->datetime)) ? date('Y-m-d', strtotime($article->datetime)) : date('Y-m-d')); ?>">
										<input type="time" name="time" id="time" class="form-control" placeholder="isi disini" value="<?php echo e(($data['form']['class']=='form-update' && !empty($article->datetime)) ? date('H:i', strtotime($article->datetime)) : date('H:i')); ?>">	
									</div>
								</div>
							</div>
		
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_tag" aria-expanded="false" aria-controls="accor_tag"><b class="badge bg-primary me-1"><?php echo e(count($article->tags)); ?></b>Tag</button>
								</h2>
								<div id="accor_tag" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<div class="input-group">
											<input type="text" id="tags" class="form-control tag-input" placeholder="isi disini" value="<?php echo e(old('tags')); ?>">
											<button type="button" class="btn btn-dark tag-button" data-bs-toggle="tooltip" data-bs-original-title="Tambah topik" data-bs-placement="bottom">
												<i class="bx bx-bookmark-plus"></i>
											</button>
										</div>
										<div id="tag-preview">
											<?php if($data['form']['class']=='form-update' && $article->tags!='null'): ?>
												<?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<span class="badge bg-primary mt-1 me-1"><i class="bx bx-x text-danger cursor-pointer me-1 tag-remove"></i><?php echo e($tag); ?><input type="hidden" name="tags[]" value="<?php echo e($tag); ?>"></span>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_author" aria-expanded="false" aria-controls="accor_author">Penulis</button>
								</h2>
								<div id="accor_author" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<input type="text" name="author" id="author" class="form-control" placeholder="isi disini" value="<?php echo e($article->author ?? old('author')); ?>">
									</div>
								</div>
							</div>
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_description" aria-controls="accor_description" aria-expanded="true">Deskripsi singkat</button>
								</h2>
								<div id="accor_description" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<textarea name="description" id="description" class="form-control" placeholder="isi disini"><?php echo e($article->description ?? old('description')); ?></textarea>
									</div>
								</div>
							</div>
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_related" aria-controls="accor_related" aria-expanded="false"><b class="badge bg-primary me-1"><?php echo e(count($article_related)); ?></b>Berita terkait</button>
								</h2>
							  <div id="accor_related" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
								  <div class="accordion-body">
										<select name="related[]" id="related" class="form-control select2-news w-100" multiple data-url="<?php echo e(route('article.option')); ?>">
											<?php $__currentLoopData = $article_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($item->id); ?>" <?php if(true): echo 'selected'; endif; ?>><?php echo e($item->title); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
								  </div>
							  </div>
						  </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('node_modules/select2/dist/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="https://cdn.tiny.cloud/1/9itgriy90vlqq8utp58vwdgdp06frez49d36w3lv684grblh/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<?php echo $__env->make('layouts.panel.storage-modal', ['mode'=>'single'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.panel.input-youtube-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
	$("input[name=publish]").on('change', function(e) {
		if (e.target.value=='schedule') {
			$("#scheduled").removeClass('d-none');
		} else {
			$("#scheduled").addClass('d-none');
		}
	})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/article/form.blade.php ENDPATH**/ ?>