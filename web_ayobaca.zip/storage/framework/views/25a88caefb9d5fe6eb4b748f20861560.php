<?php
	$menu = [
		[
			'title' => 'Dasbor',
			'menu'	=> [
				[
					'id'	=> ['ae.dashboard'],
					'title'	=> 'Dasbor',
					'url'	=> route('ae.dashboard'),
					'icon'	=> 'bx bxs-dashboard',
					'sub'	=> []
				],
			]
		],
		[
			'title'	=> 'Berita',
			'menu'	=> [
                [
					'id'	=> ['ae.article.create'],
					'title'	=> 'Tulis berita',
					'url'	=> route('ae.article.create'),
					'icon'	=> 'bx bx-edit',
					'sub'	=> []
				],
				[
					'id'	=> ['ae.article.comment', 'ae.article.publish', 'ae.article.draft', 'ae.article.schedule', 'ae.article.edit'],
					'title'	=> 'Berita',
					'url'	=> route('ae.article.publish'),
					'icon'	=> 'bx bx-news',
					'sub'	=> [
						[
							'id'	=> ['ae.article.publish', 'ae.article.comment'],
							'title'	=> 'Rilis',
							'url'	=> route('ae.article.publish')
						],
						[
							'id'	=> ['ae.article.draft'],
							'title'	=> 'Draft',
							'url'	=> route('ae.article.draft')
						],
						[
							'id'	=> ['ae.article.schedule'],
							'title'	=> 'Terjadwal',
							'url'	=> route('ae.article.schedule')
						],
					]
				],
                [
					'id'	=> ['articlecategory.index', 'articlecategory.create', 'articlecategory.edit'],
					'title'	=> 'Kategori berita',
					'url'	=> route('articlecategory.index'),
					'icon'	=> 'bx bxs-news',
					'sub'	=> []
				],
			]
		],
	]
?>
<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
	<div class="app-brand py-2">
		<a class="app-brand-link">
			<span class="app-brand-logo">
				<i class="bx bx-customize text-primary fs-1"></i>
			</span>
			<span class="app-brand-text menu-text fw-bolder ms-2">
				<?php if(Auth::user()->role=='admin'): ?>
				<?php echo e(Str::title('panel')); ?>

				<?php elseif(Auth::user()->role=='developer'): ?>
				<span class="badge badge-tag warning" data-tag="dev"><?php echo e(Str::title('panel')); ?></span>
				<?php endif; ?>
			</span>
		</a>
		<a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
			<i class="bx bx-chevron-left bx-sm align-middle"></i>
		</a>
	</div>
	<div class="menu-inner-shadow"></div>
	<ul class="menu-inner py-1">
		<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="menu-header small text-uppercase m-0">
			<span class="menu-header-text"><?php echo e($nav['title']); ?></span>
		</li>
		<?php if(count($nav['menu']) > 0): ?>
		<?php $__currentLoopData = $nav['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if(count($nav_link['sub']) > 0): ?>
		<li class="menu-item <?php echo e((in_array(Route::currentRouteName(), $nav_link['id'])) ? 'active open' : null); ?>">
			<a href="javascript:void(0);" class="menu-link menu-toggle text-decoration-none">
				<i class="menu-icon tf-icons <?php echo e($nav_link['icon']); ?>"></i>
				<div data-i18n="<?php echo e($nav_link['title']); ?>"><?php echo e($nav_link['title']); ?></div>
			</a>
			<ul class="menu-sub">
				<?php $__currentLoopData = $nav_link['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="menu-item <?php echo e((in_array(Route::currentRouteName(), $sub_link['id'])) ? 'active open' : null); ?>">
					<a href="<?php echo e($sub_link['url']); ?>" class="menu-link text-decoration-none">
						<div data-i18n="<?php echo e($sub_link['title']); ?>"><?php echo e($sub_link['title']); ?></div>
					</a>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</li>
		<?php else: ?>
		<li class="menu-item <?php echo e((in_array(Route::currentRouteName(), $nav_link['id'])) ? 'active' : null); ?>">
			<a href="<?php echo e($nav_link['url']); ?>" class="menu-link text-decoration-none">
				<i class="menu-icon tf-icons <?php echo e($nav_link['icon']); ?>"></i>
				<div data-i18n="<?php echo e($nav_link['title']); ?>"><?php echo e($nav_link['title']); ?></div>
			</a>
		</li>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<li class="menu-header small text-uppercase">
			<span class="menu-header-text"></span>
		</li>
		<li class="menu-item">
			<a href="<?php echo e(route('logout')); ?>" class="menu-link text-decoration-none text-white bg-danger" 
			onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
				<i class="menu-icon tf-icons bx bx-exit"></i>
				<div data-i18n="Logout"><?php echo e(__('Logout')); ?></div>
			</a>
		</li>
	</ul>
</aside><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/layouts/editor/app-menu.blade.php ENDPATH**/ ?>