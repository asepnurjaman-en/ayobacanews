
<?php $__env->startSection('title', $category->title." | ".Str::title($global['setting'][0]->content)); ?>
<?php $__env->startSection('content'); ?>
<section class="py-2">
	<div class="container">
		
		<div class="row g-2 mb-2">
			<div class="col-lg-9">
				<div class="row g-2">
					<div class="col-lg-8">
						<div class="ayobaca-title">
							<h1>
								<i class="icon-feed rounded-1 shadow-sm" style="<?php echo \Illuminate\Support\Arr::toCssStyles('background-color:'.$category->color) ?>"></i>
								<span><?php echo e($category->title); ?></span>
							</h1>
						</div>
						<div class="ad ad-md" data-url="<?php echo e((!empty($ad_1)) ? $ad_1->url : '#'); ?>">
							<?php if(!empty($ad_1)): ?>
							<img src="<?php echo e(url('storage/'.$ad_1->file)); ?>" alt="<?php echo e($ad_1->url); ?>">
							<?php endif; ?>
						</div>
						<?php $__empty_1 = true; $__currentLoopData = $category->articles->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="news-box-lg bg-white overflow-hidden shadow-sm rounded-1">
							<?php if($item->file_type=='video'): ?>
							<div class="video">
								<iframe src="https://www.youtube-nocookie.com/embed/<?php echo e($item->file); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
							</div>
							<?php elseif($item->file_type=='image'): ?>
							<div class="image skeleton">
								<img src="<?php echo e(url('storage/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid rounded-top d-none" loading="lazy">
							</div>
							<?php endif; ?>
							<div class="desc p-3">
								<h2>
									<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
								</h2>
								<div class="d-flex align-items-center py-1 small text-muted">
									<?php echo ($item->file_type=='video') ? '<i class="bx bxl-youtube fs-5 me-2"></i>' : null; ?>

									<span class="me-2"><?php echo e(date_stat($item->datetime)); ?></span>
									<span><?php echo e($item->author); ?></span>
								</div>
								<blockquote><?php echo e($item->description); ?></blockquote>
								<div class="button">
									<a href="<?php echo e(route('l.news', $item->slug)); ?>">
										<span>baca selengkapnya</span>
										<i class="icon-arrow-down"></i>
									</a>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="empty">Segera rilis</div>
						<?php endif; ?>
						<div class="ad ad-md" data-url="<?php echo e((!empty($ad_3)) ? $ad_3->url : '#'); ?>">
							<?php if(!empty($ad_3)): ?>
							<img src="<?php echo e(url('storage/'.$ad_3->file)); ?>" alt="<?php echo e($ad_3->url); ?>">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-4">
						<?php echo $__env->make('layouts.component', ['type'=>'trending'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="ad ad-md top-stick" data-url="<?php echo e((!empty($ad_2)) ? $ad_2->url : '#'); ?>">
					<?php if(!empty($ad_2)): ?>
					<img src="<?php echo e(url('storage/'.$ad_2->file)); ?>" alt="<?php echo e($ad_2->url); ?>">
					<?php endif; ?>
				</div>
			</div>
		</div>
		
		
		<div class="row g-2 mb-2">
			<div class="col-lg-8">
				<div class="load-news bg-white shadow-sm rounded-1">
					
				</div>
			</div>
			<div class="col-lg-4">
				<div class="ad ad-md" data-url="<?php echo e((!empty($ad_4)) ? $ad_4->url : '#'); ?>">
					<?php if(!empty($ad_4)): ?>
					<img src="<?php echo e(url('storage/'.$ad_4->file)); ?>" alt="<?php echo e($ad_4->url); ?>">
					<?php endif; ?>
				</div>
				<?php echo $__env->make('layouts.component', ['type'=>'highlight'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</div>
		
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('running-text'); ?>
<?php echo $__env->make('layouts.component', ['type'=>'running-text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="og:title" content="<?php echo e($category->title); ?>">
<meta property="og:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="twitter:title" content="<?php echo e($category->title); ?>">
<meta property="twitter:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="twitter:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
	var page = 1;
	load_news(page);
	$(window).scroll(function() {
		if (($(window).scrollTop() + $(window).height() + 320) >= $(document).height()) {
			page++;
			load_news(page);
		}
		// console.log(`${$(window).scrollTop() + $(window).height() + 320} >= ${$(document).height()}`);
	});
	function load_news(page) {
		$.ajax({
			url : `<?php echo e(route('l.category.load', $category->id)); ?>`,
			type: 'get',
			data: {
				page: page
			},
			dataType: 'html',
		}).done(function(response) {
			$(".load-news").append(response);
		}).fail(function(q,w,e) {
			console.log(q.responseText);
		});
	}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/category.blade.php ENDPATH**/ ?>