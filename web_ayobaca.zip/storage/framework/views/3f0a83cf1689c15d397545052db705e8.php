
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="card border-0 my-3">
		<div class="card-header p-3">
			<div class="form-group d-flex justify-content-between">
				<button type="button" class="btn-back btn btn-outline-secondary">
					<i class="bx bx-chevron-left"></i>
					<span><?php echo e(Str::title('kembali')); ?></span>
				</button>
			</div>
		</div>
		<div class="card-body p-3">
			<div class="mb-3">
				<span><?php echo e(Str::title('riwayat suplai')); ?></span>
				<h2><?php echo e($product->title); ?></h2>
			</div>
			<div class="row g-0">
				<?php $__currentLoopData = $product_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-12 col-md-6">
					<div class="border p-2">
						<ul class="list-unstyled mb-0">
							<li>
								<span class="small text-muted"><?php echo e(Str::title('tanggal')); ?></span>
								<span class="d-block text-dark lh-1"><?php echo e($item->date); ?></span>
							</li>
							<li>
								<span class="small text-muted"><?php echo e(Str::title('jumlah')); ?></span>
								<span class="d-block text-dark lh-1"><?php echo e($item->stock); ?></span>
							</li>
							<li>
								<span class="small text-muted"><?php echo e(Str::title('subtotal bayar')); ?></span>
								<span class="d-block text-dark lh-1"><?php echo e(idr($item->subtotal)); ?></span>
							</li>
							<li>
								<span class="small text-muted"><?php echo e(Str::title('penyuplai')); ?></span>
								<span class="d-block text-dark lh-1"><?php echo anchor(text:$item->supplier->name, href:route('product-supplier.edit', $item->supplier->id)); ?></span>
							</li>
						</ul>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/product/show-stock.blade.php ENDPATH**/ ?>