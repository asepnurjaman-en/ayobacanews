<?php $__env->startSection('title', ucfirst('login')); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-body">
		<h4 class="mb-1"><?php echo e(Str::upper('login')); ?></h4>
		<p class="mb-3"><?php echo e(ucfirst('tetap jaga kerahasiaan akun anda.')); ?></p>
		<form method="POST" action="<?php echo e(route('login')); ?>" id="formAuthentication" class="mb-3">
			<?php echo csrf_field(); ?>
			<div class="mb-3">
				<label for="email" class="form-label"><?php echo e(__('email')); ?></label>
				<input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="mb-3 form-password-toggle">
				<div class="d-flex justify-content-between">
					<label class="form-label" for="password"><?php echo e(__('password')); ?></label>
				</div>
				<div class="input-group input-group-merge">
					<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
					<span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
				</div>
			</div>
			<div class="mb-3">
				<div class="form-check">
					<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
					<label class="form-check-label" for="remember">
						<?php echo e(__('Ingat saya')); ?>

					</label>
				</div>
			</div>
			<div class="mb-3">
				<button class="btn btn-primary d-grid w-100" type="submit"><?php echo e(Str::upper('masuk')); ?></button>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/auth/login.blade.php ENDPATH**/ ?>