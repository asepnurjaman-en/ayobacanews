
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<span></span>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-3">
							<label for="product_id" class="form-label mb-1"><?php echo e(__('produk')); ?></label>
							<select name="product_id" id="product_id" class="form-control select2 product_id">
								<option disabled selected><?php echo e(Str::title('-- pilih produk --')); ?></option>
								<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
					<div class="col-12 col-md-6">
						<div class="form-group mb-3">
							<label for="stock" class="form-label mb-1"><?php echo e(__('jumlah')); ?></label>
							<input type="number" name="stock" id="stock" class="form-control" placeholder="isi disini" min="0" max="1000000">
						</div>
						<div class="form-group mb-3">
							<label for="subtotal" class="form-label mb-1"><?php echo e(__('subtotal')); ?></label>
							<input type="text" name="subtotal" id="subtotal" class="form-control" placeholder="isi disini">
						</div>
						<div class="form-group mb-3">
							<label for="supplier_id" class="form-label mb-1"><?php echo e(__('penyuplai')); ?></label>
							<select name="supplier_id" id="supplier_id" class="form-control select2">
								<option disabled selected><?php echo e(Str::title('-- pilih penyuplai --')); ?></option>
								<?php $__empty_1 = true; $__currentLoopData = $product_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<option><?php echo e(__('empty')); ?></option>
								<?php endif; ?>
							</select>
						</div>
						<div class="form-group mb-3">
							<label for="date" class="form-label mb-1"><?php echo e(__('tanggal')); ?></label>
							<input type="date" name="date" id="date" class="form-control" placeholder="isi disini" value="<?php echo e(date('Y-m-d')); ?>" max="<?php echo e(date('Y-m-d')); ?>">
						</div>
					</div>
					<div class="col-12 col-md-6">
						<div class="bg-light rounded border mt-4 p-3">
							<div>
								<span class="text-muted small lh-1"><?php echo e(Str::title('stok saat ini')); ?></span>
								<span id="currentStock" class="d-block fs-1 fw-bold lh-1 mb-3">0</span>
							</div>
							<div>
								<span class="text-muted small lh-1"><?php echo e(Str::title('riwayat')); ?></span>
								<ul id="currentHistory" class="p-0 list-unstyled"></ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/select2/dist/js/select2.min.js')); ?>" type="text/javascript"></script>
<script>
	let IDR = new Intl.NumberFormat('id-ID', {
    	style: 'currency',
    	currency: 'IDR',
	});
	$(".product_id").on('change', function(e) {
		e.preventDefault();
		let action	= '<?php echo e(route('product-stock.list')); ?>',
			csrf	= $("meta[name=csrf-token]").attr('content'),
			id		= $(".product_id :selected").val();
		$.ajax({
			type: 'post',
			url : action,
			data: {
				_token: csrf, id: id
			},
			dataType: 'json',
			beforeSend: function() {
				$(".product_id").prop('disabled', true);
				$("#currentHistory").html('loading..');
			},
			success: function(response) {
				$(".product_id").prop('disabled', false);
				$("#currentStock").text(response.stock);
				$("#currentHistory").html(null);
				for (var i in response.data) {
					$("#currentHistory").append(`<li class="d-flex justify-content-between"><span>${response.data[i].date}</span><span>&times;${response.data[i].stock}</span><span>${IDR.format(response.data[i].subtotal)}</span></li>`);
				};
				$("#currentHistory").append(`<li class="py-2">${response.link}</li>`);
			}
		})
	})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/product/form-stock.blade.php ENDPATH**/ ?>