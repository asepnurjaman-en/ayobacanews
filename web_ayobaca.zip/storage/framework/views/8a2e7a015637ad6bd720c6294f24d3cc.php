
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-12">
			<form action="<?php echo e($data['delete']['action']); ?>" method="post" class="form-delete my-3 mb-0" data-message="<?php echo e($data['delete']['message']); ?>">
				<?php echo method_field('DELETE'); ?>
				<input type="hidden" name="id_delete" value/>
				<a href="<?php echo e($data['create']['action']); ?>" class="btn btn-success">
					<i class="bx bx-plus"></i>
					<span><?php echo e(Str::title('tambah baru')); ?></span>
				</a>
				<button type="submit" class="btn btn-danger" disabled>
					<i class="bx bx-trash"></i>
					<span><?php echo e(Str::title('hapus')); ?></span>
					<b></b>
				</button>
			</form>
			<div class="card border-0 my-3">
				<div class="card-body p-2">
					<div class="row g-2">
						<?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="col-6 col-md-3">
							<div class="grid-image">
								<?php if($item->type=='photo'): ?>
								<?php echo image(src:url('storage/sm/'.$item->file), alt:$item->file); ?>

								<div class="overlay">
									<?php echo input_check(name:"check[]", value:$item->id, class:['form-check-input', 'check-row'], mode:'multiple'); ?>

									<div class="title">
										<?php echo ($item->grouped=='1') ? "<span class=\"badge bg-primary\">Album</span>" : "<span class=\"badge bg-warning\">Foto</span>"; ?>

										<h3><?php echo anchor(text:$item->title, href:route('gallery-photo.edit', $item->id)); ?></h3>
										<?php echo ($item->grouped=='1') ? anchor(text:Str::title('buka album'), class:['btn', 'btn-light', 'btn-sm', 'w-100'], href:route('gallery-photo.edit-files', $item->id)) : null; ?>

									</div>
								</div>
								<?php elseif($item->type=='video'): ?>
								<?php echo image(src:"https://img.youtube.com/vi/$item->file/hqdefault.jpg"); ?>

								<div class="overlay">
									<?php echo input_check(name:"check[]", value:$item->id, class:['form-check-input', 'check-row'], mode:'multiple'); ?>

									<div class="title">
										<?php echo ($item->grouped=='1') ? "<span class=\"badge bg-primary\">Album</span>" : "<span class=\"badge bg-danger\">Youtube</span>"; ?>

										<h3><?php echo anchor(text:$item->title, href:route('gallery-video.edit', $item->id)); ?></h3>
									</div>
									<?php echo ($item->grouped=='1') ? anchor(text:Str::title('buka album'), class:['btn', 'btn-light', 'btn-sm', 'w-100'], href:route('gallery-photo.edit-files', $item->id)) : null; ?>

								</div>
								<?php endif; ?>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							
						<?php endif; ?>
					</div>
				</div>
				<div class="card-footer py-0">
					<?php echo $gallery->links(); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/gallery/index.blade.php ENDPATH**/ ?>