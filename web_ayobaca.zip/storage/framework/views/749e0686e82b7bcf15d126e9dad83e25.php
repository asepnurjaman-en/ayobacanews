<?php if($type=='running-text'): ?>
<div class="top-pick">
	<div class="label">Top picks</div>
	<div class="running-text">
		<marquee direction="" onmouseover="this.stop();" onmouseout="this.start();">
			<?php $__currentLoopData = $running; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="<?php echo e(route('l.news', $item->article->slug)); ?>" class="running-news"><?php echo e($item->article->title); ?></a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</marquee>
	</div>
</div>
<?php elseif($type=='highlight'): ?>
<div class="bg-white shadow-sm rounded-1 top-stick">
	<div class="p-2 border-bottom">
		<h4 class="mb-0">Highlight</h4>
	</div>
	<?php $__empty_1 = true; $__currentLoopData = $highlight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<div class="news-box-sm p-2 lh-sm border-bottom">
		<div class="d-flex align-items-center">
			<div class="image">
				<img src="<?php echo e(($item->article->file_type=='video') ? "https://img.youtube.com/vi/{$item->article->file}/hqdefault.jpg" : url('storage/md/'.$item->article->file)); ?>" alt="<?php echo e($item->article->file_source); ?>" class="rounded-sm shadow-sm img-fluid">
			</div>
			<div class="desc">
				<a href="<?php echo e(route('l.news', $item->article->slug)); ?>"><?php echo e($item->article->title); ?></a>
			</div>
		</div>
		<div class="d-flex justify-content-between pt-2 small text-muted">
			<div class="d-flex align-items-center">
				<?php echo ($item->article->file_type=='video') ? '<i class="bx bxl-youtube fs-5 me-2"></i>' : null; ?>

				<span class="fw-bold me-1"><?php echo e($item->article->article_category->title); ?> &dash;</span>
				<span><?php echo e(date_stat($item->article->datetime)); ?></span>
			</div>
			<span><?php echo e($item->article->author); ?></span>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="empty">Segera rilis</div>
	<?php endif; ?>
</div>
<?php elseif($type=='trending'): ?>
<div class="bg-white shadow-sm rounded-1 top-stick mb-2">
	<div class="p-2 border-bottom">
		<h4 class="mb-0"><b>Top</b> Trending</h4>
	</div>
	<?php $__empty_1 = true; $__currentLoopData = $trending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<div class="news-box-sm p-2 lh-sm border-bottom">
		<a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo e($item->title); ?></a>
		<div class="d-flex justify-content-between pt-2 small text-muted">
			<div class="d-flex align-items-center">
				<?php echo ($item->file_type=='video') ? '<i class="bx bxl-youtube fs-5 me-2"></i>' : null; ?>

				<span class="fw-bold me-1"><?php echo e($item->article_category->title); ?> &dash; </span>
				<span><?php echo e(date_stat($item->datetime)); ?></span>
			</div>
			<span><?php echo e($item->author); ?></span>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="empty">Segera rilis</div>
	<?php endif; ?>
</div>
<?php endif; ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/layouts/component.blade.php ENDPATH**/ ?>