<?php
    $active = $active ?? 0;
?>
<header class="ayobaca-header">
    <div class="container-fluid d-flex justify-content-between align-items-center py-2">
        <div class="logo">
            <a href="<?php echo e(route('l.home')); ?>">
                <img src="<?php echo e(url('storage/'.$global['setting'][2]->content)); ?>" alt="Logo" class="img-fluid">
            </a>
        </div>
        <div class="search">
            <form action="<?php echo e(route('l.search')); ?>" method="get">
                <input type="search" name="q" placeholder="Cari apa?" value="<?php echo e(request()->get('q') ?? null); ?>">
                <button type="submit">
                    <i class="icon-magnifier"></i>
                </button>
            </form>
        </div>
    </div>
    <nav>
        <button type="button" class="navLeft shadow-sm hide"><</button>
        <a href="<?php echo e(route('l.home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => (Route::currentRouteName()=='l.home')]) ?>">
            <i class="icon-book-open"></i>
            <span>Beranda</span>
        </a>
        <?php $__currentLoopData = $global['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('l.category', $item->slug)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => ($active==$item->id)]) ?>"><?php echo e($item->title); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('l.contact')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => (Route::currentRouteName()=='l.contact')]) ?>">Kontak Kami</a>
    </nav>
</header>
<div class="top-holder"></div><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/layouts/app-nav.blade.php ENDPATH**/ ?>