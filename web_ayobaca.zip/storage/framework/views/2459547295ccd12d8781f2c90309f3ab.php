
<?php $__env->startSection('title', $info->title.' | '.Str::title($global['setting'][0]->content)); ?>
<?php $__env->startSection('content'); ?>
<section class="py-4">
	<div class="container">
		<div class="bg-white rounded-sm p-4">
			<div class="ayobaca-title">
				<h1>
					<span><?php echo e($info->title); ?></span>
				</h1>
			</div>
			<?php echo $info->content; ?>

		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('running-text'); ?>
<?php echo $__env->make('layouts.component', ['type'=>'running-text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="og:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="og:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="twitter:title" content="<?php echo e($global['setting'][0]->content); ?>">
<meta property="twitter:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="twitter:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/other.blade.php ENDPATH**/ ?>