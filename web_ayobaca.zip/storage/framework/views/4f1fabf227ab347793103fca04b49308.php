
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row g-3">
		<div class="col-12">
			<div class="category_navbar bg-white rounded shadow-sm mt-3 p-3">
				<div class="d-flex st">
					<a href="?" class="btn btn-outline-primary text-nowrap me-1 <?php echo e((empty(request()->category)) ? 'active' : null); ?>">
						<i class="bx bx-list-ul"></i>
						<span>Semua</span>
					</a>
					<?php $__currentLoopData = $global['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="?category=<?php echo e($category->slug); ?>" class="btn btn-outline-primary text-nowrap me-1 <?php echo e((request()->category==$category->slug) ? 'active' : null); ?>">
						<?php echo e($category->title); ?>

					</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
		<div class="col-12">
			<form action="<?php echo e($data['delete']['action']); ?>" method="post" class="form-delete mb-0" data-message="<?php echo e($data['delete']['message']); ?>">
				<?php echo method_field('DELETE'); ?>
				<input type="hidden" name="id_delete" value/>
				<a href="<?php echo e($data['create']['action']); ?>" class="btn btn-success">
					<i class="bx bx-plus"></i>
					<span><?php echo e(Str::title('tambah baru')); ?></span>
				</a>
				<button type="submit" class="btn btn-danger" disabled>
					<i class="bx bx-trash"></i>
					<span><?php echo e(Str::title('hapus')); ?></span>
					<b></b>
				</button>
			</form>
			<div class="card border-0 my-3">
				<div class="card-body p-0">
					<table class="dataTables" data-list="<?php echo e($data['list']); ?>">
						<thead>
							<tr>
								<th><i class="bx bx-cog"></i></th>
								<th></th>
								<th></th>
								<th></th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
	<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.editor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/editor/article/index.blade.php ENDPATH**/ ?>