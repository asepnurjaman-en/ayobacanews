
<?php $__env->startSection('title', "Cari | ".Str::title($global['setting'][0]->content)); ?>
<?php
    $needle = request()->get('q') ?? '';
?>
<?php $__env->startSection('content'); ?>
<section class="py-2">
	<div class="container">
		
		<div class="row g-2 mb-2">
            <div class="col-lg-8">
                <div class="ayobaca-title">
                    <h1>
                        <i class="icon-feed bg-secondary rounded-1 shadow-sm"></i>
                        <span>Cari</span>
                    </h1>
                </div>
                <div class="bg-white shadow-sm rounded-1">
                    <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="news-list-md p-3">
                        <div class="d-flex">
                            <div class="image me-2">
                                <img src="<?php echo e(($item->file_type=='video') ? "https://img.youtube.com/vi/{$item->file}/hqdefault.jpg" : url('storage/md/'.$item->file)); ?>" alt="<?php echo e($item->file_source); ?>" class="img-fluid rounded-top">
                            </div>
                            <div class="desc">
                                <h3>
                                    <a href="<?php echo e(route('l.news', $item->slug)); ?>"><?php echo highlight($needle, $item->title); ?></a>
                                </h3>
                                <div class="d-flex align-items-center py-1 small text-muted">
                                    <?php echo ($item->file_type=='video') ? '<i class="bx bxl-youtube fs-5 me-2"></i>' : null; ?>

                                    <span class="me-2"><?php echo e(date_stat($item->datetime)); ?></span>
                                    <span><?php echo e($item->author); ?></span>
                                </div>
                                <blockquote><?php echo e($item->description); ?></blockquote>
                                <?php if(count(json_decode($item->tags))>0): ?>
                                <div class="tag my-1">
                                    <?php $__currentLoopData = json_decode($item->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('l.tag', $tag)); ?>" class="text-primary fw-bold mb-1">#<?php echo e($tag); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">Segera rilis</div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-4">
                <?php echo $__env->make('layouts.component', ['type'=>'trending'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
		
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('running-text'); ?>
<?php echo $__env->make('layouts.component', ['type'=>'running-text'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:type" content="article">
<meta property="og:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="og:title" content="<?php echo e($needle); ?>">
<meta property="og:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="og:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(request()->fullUrl()); ?>">
<meta property="twitter:title" content="<?php echo e($needle); ?>">
<meta property="twitter:description" content="<?php echo e(strip_tags($global['setting'][4]->content)); ?>">
<meta property="twitter:image" content="<?php echo e(url('storage/sm/'.$global['setting'][2]->content)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/search.blade.php ENDPATH**/ ?>