<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	
	
	
	
	<link rel="shortcut icon" href="<?php echo e(url('sneat/img/favicon.png')); ?>" type="image/x-icon">
    
	<?php echo app('Illuminate\Foundation\Vite')(['resources/css/sneat-auth.css']); ?>
</head>
<body>
	<div class="container-xxl">
		<div class="authentication-wrapper authentication-basic container-p-y">
			<div class="authentication-inner">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</div>
		<div class="layout-overlay layout-menu-toggle"></div>
	</div>
	
    <script src="<?php echo e(asset('node_modules/jquery/dist/jquery.min.js')); ?>"></script>
    
	<?php echo app('Illuminate\Foundation\Vite')(['resources/js/sneat-auth.js']); ?>
</body>
</html><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/layouts/panel/auth.blade.php ENDPATH**/ ?>