
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php
	if (is_object($ad_1)) :
		$ad_1_prop = [
			'ad'	=> [
				'id'	=> $ad_1->id,
				'file'	=> url('storage/'.$ad_1->file),
			],
			'random'=> false,
			'delete'=> false,
		];
	elseif ($ad_1=='random') :
		$ad_1_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> true,
			'delete'=> true,
		];
	elseif ($ad_1==null) :
		$ad_1_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> false,
			'delete'=> true,
		];
	endif;
	if (is_object($ad_2)) :
		$ad_2_prop = [
			'ad'	=> [
				'id'	=> $ad_2->id,
				'file'	=> url('storage/'.$ad_2->file),
			],
			'random'=> false,
			'delete'=> false,
		];
	elseif ($ad_2=='random') :
		$ad_2_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> true,
			'delete'=> true,
		];
	elseif ($ad_2==null) :
		$ad_2_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> false,
			'delete'=> true,
		];
	endif;
	if (is_object($ad_3)) :
		$ad_3_prop = [
			'ad'	=> [
				'id'	=> $ad_3->id,
				'file'	=> url('storage/'.$ad_3->file),
			],
			'random'=> false,
			'delete'=> false,
		];
	elseif ($ad_3=='random') :
		$ad_3_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> true,
			'delete'=> true,
		];
	elseif ($ad_3==null) :
		$ad_3_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> false,
			'delete'	=> true,
		];
	endif;
	if (is_object($ad_4)) :
		$ad_4_prop = [
			'ad'	=> [
				'id'	=> $ad_4->id,
				'file'	=> url('storage/'.$ad_4->file),
			],
			'random'=> false,
			'delete'=> false,
		];
	elseif ($ad_4=='random') :
		$ad_4_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> true,
			'delete'=> true,
		];
	elseif ($ad_4==null) :
		$ad_4_prop = [
			'ad'	=> [
				'id'	=> null,
				'file'	=> null,
			],
			'random'=> false,
			'delete'=> true,
		];
	endif;
?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="form-group">
			<div class="input-group bg-white rounded">
				<button type="button" class="btn-back btn btn-outline-secondary">
					<i class="bx bx-chevron-left"></i>
					<span><?php echo e(Str::title('kembali')); ?></span>
				</button>
				<input type="text" name="title" id="title" class="form-control bg-white" placeholder="isi disini" value="<?php echo e($article->title ?? old('title')); ?>" maxlength="110" disabled>
			</div>
		</div>
		<div class="ad-setup my-1">
			<div class="card border-0 my-3">
				<div class="card-header">
					<div class="form-group d-flex justify-content-between">
						<h4 class="mb-0">Kelola iklan</h4>
						<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
							<i class="bx bx-save"></i>
							<span><?php echo e(Str::title('simpan')); ?></span>
						</button>
					</div>
				</div>
				<div class="card-body">
					<div class="row g-2">
						<div class="col-12 col-lg-9">
							<div class="row g-2">
								<div class="col-12 col-lg-8">
									<div id="ad-space-1" class="border p-1 mb-2">
										<div class="ad-space border">
											<img src="<?php echo e($ad_1_prop['ad']['file']); ?>" alt="" class="img-fluid">
											<div class="overlay">
												<button type="button" class="btn btn-primary btn-sm open-ad me-1" data-bs-toggle="modal" data-bs-target="#input-ad-modal" data-ad-position="1">
													Pilih iklan
												</button>
											</div>
										</div>
										<div class="d-flex justify-content-between my-1">
											<div class="form-check form-switch ms-1">
												<input class="form-check-input" type="checkbox" name="ad-random-1" id="ad-random-1" <?php if($ad_1_prop['random']): echo 'checked'; endif; ?>>
												<label class="form-check-label" for="ad-random-1">Acak</label>
											</div>
											<button type="button" class="btn btn-danger btn-sm close-ad" data-ad-position="1" <?php if($ad_1_prop['delete']): echo 'disabled'; endif; ?>>
												<i class="bx bxs-trash"></i>
											</button>
										</div>
										<input type="hidden" name="ad-input-1" id="ad-input-1" value="<?php echo e($ad_1_prop['ad']['id']); ?>">
									</div>
									<div class="block-space border mb-2">Konten</div>
									<div id="ad-space-3" class="border p-1">
										<div class="ad-space border">
											<img src="<?php echo e($ad_3_prop['ad']['file']); ?>" alt="" class="img-fluid">
											<div class="overlay">
												<button type="button" class="btn btn-primary btn-sm open-ad me-1" data-bs-toggle="modal" data-bs-target="#input-ad-modal" data-ad-position="3">
													Pilih iklan
												</button>
											</div>
										</div>
										<div class="d-flex justify-content-between my-1">
											<div class="form-check form-switch ms-1">
												<input class="form-check-input" type="checkbox" name="ad-random-3" id="ad-random-3" <?php if($ad_3_prop['random']): echo 'checked'; endif; ?>>
												<label class="form-check-label" for="ad-random-3">Acak</label>
											</div>
											<button type="button" class="btn btn-danger btn-sm close-ad" data-ad-position="3" <?php if($ad_3_prop['delete']): echo 'disabled'; endif; ?>>
												<i class="bx bxs-trash"></i>
											</button>
										</div>
										<input type="hidden" name="ad-input-3" id="ad-input-3" value="<?php echo e($ad_3_prop['ad']['id']); ?>">
									</div>
								</div>
								<div class="col-12 col-lg-4">
									<div class="block-space border">Konten</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-lg-3">
							<div id="ad-space-2" class="border p-1 mb-2">
								<div class="ad-space border">
									<img src="<?php echo e($ad_2_prop['ad']['file']); ?>" alt="" class="img-fluid">
									<div class="overlay">
										<button type="button" class="btn btn-primary btn-sm open-ad me-1" data-bs-toggle="modal" data-bs-target="#input-ad-modal" data-ad-position="2">
											Pilih iklan
										</button>
									</div>
								</div>
								<div class="d-flex justify-content-between my-1">
									<div class="form-check form-switch ms-1">
										<input class="form-check-input" type="checkbox" name="ad-random-2" id="ad-random-2" <?php if($ad_2_prop['random']): echo 'checked'; endif; ?>>
										<label class="form-check-label" for="ad-random-2">Acak</label>
									</div>
									<button type="button" class="btn btn-danger btn-sm close-ad" data-ad-position="2" <?php if($ad_2_prop['delete']): echo 'disabled'; endif; ?>>
										<i class="bx bxs-trash"></i>
									</button>
								</div>
								<input type="hidden" name="ad-input-2" id="ad-input-2" value="<?php echo e($ad_2_prop['ad']['id']); ?>">
							</div>
							<div class="block-space border">Konten</div>
						</div>
						<div class="col-12 col-lg-8">
							<div class="block-space border">Konten</div>
						</div>
						<div class="col-12 col-lg-4">
							<div id="ad-space-4" class="border p-1 mb-2">
								<div class="ad-space border">
									<img src="<?php echo e($ad_4_prop['ad']['file']); ?>" alt="" class="img-fluid">
									<div class="overlay">
										<button type="button" class="btn btn-primary btn-sm open-ad me-1" data-bs-toggle="modal" data-bs-target="#input-ad-modal" data-ad-position="4">
											Pilih iklan
										</button>
									</div>
								</div>
								<div class="d-flex justify-content-between my-1">
									<div class="form-check form-switch ms-1">
										<input class="form-check-input" type="checkbox" name="ad-random-4" id="ad-random-4" <?php if($ad_4_prop['random']): echo 'checked'; endif; ?>>
										<label class="form-check-label" for="ad-random-4">Acak</label>
									</div>
									<button type="button" class="btn btn-danger btn-sm close-ad" data-ad-position="4" <?php if($ad_4_prop['delete']): echo 'disabled'; endif; ?>>
										<i class="bx bxs-trash"></i>
									</button>
								</div>
								<input type="hidden" name="ad-input-4" id="ad-input-4" value="<?php echo e($ad_4_prop['ad']['id']); ?>">
							</div>
							<div class="block-space border mb-2">Konten</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php echo $__env->make('layouts.panel.input-ad-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script>
	$(".open-ad").on('click', function() {
		let position = $(this).data('ad-position');
		$(".select-ad").attr('id', position);
	});
	$(document).on('click', '.select-ad', function(e) {
		e.preventDefault();
		let id = $(this).data('id'),
			image = $(this).data('image'),
			position = $(this).attr('id');
		$("#ad-space-"+position).find('.ad-space').find('img').attr('src', image);
		$("#ad-space-"+position).find('.close-ad').prop('disabled', false);
		$("#ad-random-"+position).prop('disabled', true).prop('checked', false);
		$("#ad-input-"+position).val(id);
		setTimeout(() => {
			$("#input-ad-modal").modal('hide');
		}, 200);
	});
	$(document).on('click', '.close-ad', function(e) {
		let position = $(this).data('ad-position');
		$(this).prop('disabled', true);
		$("#ad-space-"+position).find('.ad-space').children('img').attr('src', null);
		$("#ad-random-"+position).prop('disabled', false).prop('checked', true);
		$("#ad-input-"+position).val(null);
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/article/ad-category.blade.php ENDPATH**/ ?>