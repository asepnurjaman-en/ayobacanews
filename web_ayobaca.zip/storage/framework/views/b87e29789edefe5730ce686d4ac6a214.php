
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="my-3">
		<div class="mb-3"><?php echo $greating; ?></div>
		<div class="row g-2">
		<?php $__currentLoopData = $dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-12 col-md-4">
			<div class="card">
				<div class="card-body">
					<div class="card-title d-flex align-items-start justify-content-between">
						<div class="d-flex align-items-center">
							<i class="<?php echo e($item['icon']); ?> me-1 fs-2"></i>
							<span class="fw-semibold d-block mb-1"><?php echo e(Str::title($item['title'])); ?></span>
						</div>
					</div>
					<h3 class="card-title mb-2"><?php echo e($item['data']); ?></h3>
					<?php echo anchor(href:$item['url'], text:Str::title('kelola')); ?>

				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/index.blade.php ENDPATH**/ ?>