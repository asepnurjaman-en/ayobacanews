
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
	<div class="container-fluid flex-grow-1 container-p-y position-relative">
		<ul class="nav nav-pills flex-column flex-md-row mb-3">
			<?php $__currentLoopData = $tablist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
				<a class="nav-link <?php echo e((request()->fullUrl()==$tab['url']) ? 'active' : null); ?>" href="<?php echo e($tab['url']); ?>"><i class="<?php echo e($tab['icon']); ?> me-1"></i> <?php echo e(Str::title($tab['title'])); ?></a>
			</li>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<div class="card mb-4">
			<form action="<?php echo e($data['form']['action']); ?>" method="POST" class="<?php echo e($data['form']['class']); ?>" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PATCH'); ?>
				<div class="card-body p-3">
					<?php if(request()->tab=='site'): ?>
					<div class="mb-3 form-group">
						<label for="title" class="form-label"><?php echo e($global['setting'][0]->title); ?></label>
						<input class="form-control" type="text" id="title" name="title" value="<?php echo e($global['setting'][0]->content); ?>" required autofocus>
					</div>
					<div class="mb-3 form-group">
						<label for="color" class="form-label"><?php echo e($global['setting'][3]->title); ?></label>
						<input class="d-block border-0" type="color" id="color" name="color" value="<?php echo e($global['setting'][3]->content); ?>" placeholder="isi disini" required>
					</div>
					<?php elseif(request()->tab=='icon'): ?>
					<div class="col-12 col-md-3">
						<div class="btn-group d-flex justify-content-between">
							<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
								<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
								<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
							</label>
							<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
								<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
							</button>
						</div>
						<input type="hidden" name="file_type" id="input-file-type" value="image" readonly>
						<div id="thumbail-preview" class="mb-3">
							<div>
								<div class="item-image">
									<?php echo image(src:url('storage/sm/'.$global['setting'][1]->content), alt:$global['setting'][1]->content); ?>

									<div class="overlay">
										<button title="button" class="remove unchoose-image">&times;</button>
										<h4><?php echo e(Str::title('icon')); ?></h4>
										<input type="hidden" name="file" value="<?php echo e($global['setting'][1]->content); ?>">
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php elseif(request()->tab=='logo'): ?>
					<div class="col-12 col-md-3">
						<div class="btn-group d-flex justify-content-between">
							<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
								<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
								<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
							</label>
							<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
								<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
							</button>
						</div>
						<input type="hidden" name="file_type" id="input-file-type" value="image" readonly>
						<div id="thumbail-preview" class="mb-3">
							<div>
								<div class="item-image">
									<?php echo image(src:url('storage/sm/'.$global['setting'][2]->content), alt:$global['setting'][2]->content); ?>

									<div class="overlay">
										<button title="button" class="remove unchoose-image">&times;</button>
										<h4><?php echo e(Str::title('logo')); ?></h4>
										<input type="hidden" name="file" value="<?php echo e($global['setting'][2]->content); ?>">
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php elseif(request()->tab=='meta'): ?>
					<div class="mb-3 form-group">
						<label for="keywords" class="form-label"><?php echo e($global['setting'][5]->title); ?></label>
						<input class="form-control" type="text" id="keywords" name="keywords" value="<?php echo e($global['setting'][5]->content); ?>" required>
					</div>
					<div class="mb-3 form-group">
						<label for="description" class="form-label"><?php echo e($global['setting'][4]->title); ?></label>
						<textarea class="form-control" id="description" name="description" placeholder="isi disini" required><?php echo e($global['setting'][4]->content); ?></textarea>
					</div>
					<?php elseif(request()->tab=='maintenance'): ?>
					<div class="panel-maintenance p-3 text-center">
						<h3>Aktifkan mode `Pemeliharaan`</h3>
						<p>Ketika mode `Pemeliharaan` aktif, website akan masuk pada <b>Mode Pemeliharaan</b> dan tidak dapat akses.</p>
						<div class="form-switch mb-2">
							<input class="form-check-input" type="checkbox" id="maintenance" name="maintenance" value="on" <?php echo e(($global['setting'][6]->content=='on') ? 'checked' : null); ?>>
							<label class="form-check-label" for="maintenance">Aktifkan</label>
						</div>
					</div>
					<?php endif; ?>
					<div class="mt-2">
						<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
							<i class="bx bx-save"></i>
							<span><?php echo e(Str::title('simpan')); ?></span>
						</button>
						<button type="reset" class="btn btn-outline-secondary">
							<i class="bx bx-reset"></i>
							<span><?php echo e(Str::title('batal')); ?></span>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<?php echo $__env->make('layouts.panel.storage-modal', ['mode'=>'single'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/setting/site.blade.php ENDPATH**/ ?>