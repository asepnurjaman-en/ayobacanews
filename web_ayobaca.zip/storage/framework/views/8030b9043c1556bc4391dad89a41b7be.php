
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="card border-0 mt-3 mb-3">
		<div class="card-body">
			<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
				<?php echo csrf_field(); ?>
				<?php if($data['form']['class']=='form-update'): ?>
					<?php echo method_field('PATCH'); ?>
				<?php endif; ?>
				<div class="row g-2">
					<div class="col-12 col-lg-9">
						<select name="news" id="news" class="form-control form-control-lg select2-news w-100" data-url="<?php echo e(route('article.option')); ?>">
						</select>
					</div>
					<div class="col-12 col-lg-3">
						<button type="submit" class="btn btn-primary w-100 dont-fixit">
							<i class="bx bx-plus"></i>
							<span><?php echo e(Str::title('simpan')); ?></span>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	<?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="mb-3">
		<div class="input-group rounded shadow">
			<span class="input-group-text fw-bold"><?php echo e($key + 1); ?></span>
			<input type="text" class="form-control bg-white border-start-0" value="<?php echo e($item->article->title); ?>" <?php if(true): echo 'readonly'; endif; ?>>
			<a href="<?php echo e(route('article.running.delete', $item->id)); ?>" class="btn btn-danger">
				<i class="bx bx-x"></i>
			</a>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/select2/dist/js/select2.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/article/running.blade.php ENDPATH**/ ?>