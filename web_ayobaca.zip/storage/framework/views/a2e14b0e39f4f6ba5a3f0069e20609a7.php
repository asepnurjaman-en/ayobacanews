
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-3">
							<label for="name" class="form-label mb-1"><?php echo e(__('nama penyuplai')); ?></label>
							<input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($product_supplier->name ?? old('name')); ?>">
						</div>
						<div class="form-group mb-3">
							<label for="phone" class="form-label mb-1"><?php echo e(__('telepon')); ?></label>
							<input type="number" name="phone" id="phone" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($product_supplier->phone ?? old('phone')); ?>">
						</div>
                        <div class="form-group mb-3">
							<label for="email" class="form-label mb-1"><?php echo e(__('email')); ?></label>
							<input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($product_supplier->email ?? old('email')); ?>">
						</div>
						<div class="form-group mb-3">
							<label for="address" class="form-label mb-1"><?php echo e(__('alamat')); ?></label>
							<textarea name="address" id="address" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>"><?php echo e($product_supplier->address ?? old('address')); ?></textarea>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/product/form-supplier.blade.php ENDPATH**/ ?>