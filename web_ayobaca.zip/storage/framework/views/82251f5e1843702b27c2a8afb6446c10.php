
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PATCH'); ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<h3 class="mb-0"><?php echo e(Str::title($data['title'])); ?></h3>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row g-3">
					<div class="col-12 col-md-2">
						<ul class="nav nav-pills" role="tablist">
							<?php $__currentLoopData = $tablist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="nav-item w-100">
								<button type="button" class="nav-link py-3 <?php echo e((request()->fullUrl()==$item['url']) ? 'active' : null); ?>" role="tab" data-bs-toggle="tab" data-bs-target="#nav-<?php echo e($item['title']); ?>" aria-controls="navs-<?php echo e($item['title']); ?>" aria-selected="true">
									<i class="<?php echo e($item['icon']); ?> fs-2 d-block"></i>
									<small><?php echo e(Str::title($item['title'])); ?></small>
								</button>
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<div class="col-12 col-md-10">
						<div class="tab-content p-0">
							<div class="tab-pane fade active show" id="nav-<?php echo e($tablist[0]['title']); ?>" role="tabpanel">
								<div class="link-external_form border shadow rounded p-2 mb-3">
									<div class="d-flex justify-content-between py-2 px-3">
										<div>
											<i class="bx bx-map-alt"></i>
											<?php echo e(Str::title('alamat')); ?>

										</div>
										<div class="form-check form-switch">
											<input class="form-check-input change-input-status change-input-edited" data-edit="<?php echo e($contact['address']->type.$contact['address']->id); ?>" type="checkbox" name="active_<?php echo e($contact['address']->type.$contact['address']->id); ?>" data-brand="<?php echo e($contact['address']->type.$contact['address']->id); ?>" value="true" <?php echo e(($contact['address']->actived=='1') ? 'checked' : null); ?>>
										</div>
									</div>
									<div class="input-group input-group-merge input-group-<?php echo e($contact['address']->type.$contact['address']->id); ?> <?php echo e(($contact['address']->actived=='0') ? 'disabled' : null); ?> mb-2">
										<div class="input-group-text">
											<i class="bx <?php echo e(($contact['address']->actived=='0') ? 'bx' : 'text-primary bxs'); ?>-message-square-edit"></i>
										</div>
										<input type="text" name="title_<?php echo e($contact['address']->type.$contact['address']->id); ?>" id="title-<?php echo e($contact['address']->type.$contact['address']->id); ?>" class="form-control change-input-edited input-<?php echo e($contact['address']->type.$contact['address']->id); ?>" value="<?php echo e($contact['address']->title); ?>" data-edit="<?php echo e($contact['address']->type.$contact['address']->id); ?>" placeholder="isi disini" <?php echo e(($contact['address']->actived=='0') ? 'readonly' : null); ?>>
									</div>
									<textarea name="content_<?php echo e($contact['address']->type.$contact['address']->id); ?>" id="content-<?php echo e($contact['address']->type.$contact['address']->id); ?>" class="form-control change-input-edited input-<?php echo e($contact['address']->type.$contact['address']->id); ?>" data-edit="<?php echo e($contact['address']->type.$contact['address']->id); ?>" placeholder="isi disini" <?php echo e(($contact['address']->actived=='0') ? 'readonly' : null); ?>><?php echo e($contact['address']->content); ?></textarea>
									<input type="radio" name="edit_<?php echo e($contact['address']->type.$contact['address']->id); ?>" id="edit-<?php echo e($contact['address']->type.$contact['address']->id); ?>" value="true">
								</div>
								<div class="link-external_form border shadow rounded p-2 mb-3">
									<div class="d-flex justify-content-between py-2 px-3">
										<div>
											<i class="bx bx-map"></i>
											<?php echo e(Str::title('google map')); ?>

										</div>
										<div class="form-check form-switch">
											<input class="form-check-input change-input-status change-input-edited" data-edit="<?php echo e($contact['map']->type.$contact['map']->id); ?>" type="checkbox" name="active_<?php echo e($contact['map']->type.$contact['map']->id); ?>" data-brand="<?php echo e($contact['map']->type.$contact['map']->id); ?>" value="true" <?php echo e(($contact['map']->actived=='1') ? 'checked' : null); ?>>
										</div>
									</div>
									<div class="input-group input-group-merge input-group-<?php echo e($contact['map']->type.$contact['map']->id); ?> <?php echo e(($contact['map']->actived=='0') ? 'disabled' : null); ?> mb-2">
										<div class="input-group-text">
											<i class="bx <?php echo e(($contact['map']->actived=='0') ? 'bx' : 'text-primary bxs'); ?>-message-square-edit"></i>
										</div>
										<input type="text" name="title_<?php echo e($contact['map']->type.$contact['map']->id); ?>" id="title-<?php echo e($contact['map']->type.$contact['map']->id); ?>" class="form-control change-input-edited input-<?php echo e($contact['map']->type.$contact['map']->id); ?>" value="<?php echo e($contact['map']->title); ?>" data-edit="<?php echo e($contact['map']->type.$contact['map']->id); ?>" placeholder="isi disini" <?php echo e(($contact['map']->actived=='0') ? 'readonly' : null); ?>>
									</div>
									<textarea name="content_<?php echo e($contact['map']->type.$contact['map']->id); ?>" id="content-<?php echo e($contact['map']->type.$contact['map']->id); ?>" class="form-control change-input-edited input-<?php echo e($contact['map']->type.$contact['map']->id); ?>" data-edit="<?php echo e($contact['map']->type.$contact['map']->id); ?>" placeholder="isi disini" <?php echo e(($contact['map']->actived=='0') ? 'readonly' : null); ?>><?php echo e($contact['map']->content); ?></textarea>
									<input type="radio" name="edit_<?php echo e($contact['map']->type.$contact['map']->id); ?>" id="edit-<?php echo e($contact['map']->type.$contact['map']->id); ?>" value="true">
								</div>
							</div>
							<div class="tab-pane fade" id="nav-<?php echo e($tablist[1]['title']); ?>" role="tabpanel">
								<?php $__currentLoopData = $contact['phone']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="link-external_form border shadow rounded p-2 mb-3">
									<div class="d-flex justify-content-between py-2 px-3">
										<div>
											<i class="bx bx-phone"></i>
											<?php echo e(Str::title('telepon ').($key+1)); ?>

										</div>
										<div class="form-check form-switch">
											<input class="form-check-input change-input-status change-input-edited" data-edit="<?php echo e($item->type.$item->id); ?>" type="checkbox" name="active_<?php echo e($item->type.$item->id); ?>" data-brand="<?php echo e($item->type.$item->id); ?>" value="true" <?php echo e(($item->actived=='1') ? 'checked' : null); ?>>
										</div>
									</div>
									<div class="input-group input-group-merge input-group-<?php echo e($item->type.$item->id); ?> <?php echo e(($item->actived=='0') ? 'disabled' : null); ?> mb-2">
										<div class="input-group-text">
											<i class="bx <?php echo e(($item->actived=='0') ? 'bx' : 'text-info bxs'); ?>-message-square-edit"></i>
										</div>
										<input type="text" name="title_<?php echo e($item->type.$item->id); ?>" id="title-<?php echo e($item->type.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->type.$item->id); ?>" value="<?php echo e($item->title); ?>" data-edit="<?php echo e($item->type.$item->id); ?>" placeholder="isi disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
										<input type="text" name="content_<?php echo e($item->type.$item->id); ?>" id="content-<?php echo e($item->type.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->type.$item->id); ?>" value="<?php echo e($item->content); ?>" data-edit="<?php echo e($item->type.$item->id); ?>" placeholder="isi disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
									</div>
									<input type="radio" name="edit_<?php echo e($item->type.$item->id); ?>" id="edit-<?php echo e($item->type.$item->id); ?>" value="true">
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<hr>
								<?php $__currentLoopData = $contact['whatsapp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="link-external_form border shadow rounded p-2 mb-3">
									<div class="d-flex justify-content-between py-2 px-3">
										<div>
											<i class="bx bxl-whatsapp"></i>
											<?php echo e(Str::title('whatsapp ').($key+1)); ?>

										</div>
										<div class="form-check form-switch">
											<input class="form-check-input change-input-status change-input-edited" data-edit="<?php echo e($item->type.$item->id); ?>" type="checkbox" name="active_<?php echo e($item->type.$item->id); ?>" data-brand="<?php echo e($item->type.$item->id); ?>" value="true" <?php echo e(($item->actived=='1') ? 'checked' : null); ?>>
										</div>
									</div>
									<div class="input-group input-group-merge input-group-<?php echo e($item->type.$item->id); ?> <?php echo e(($item->actived=='0') ? 'disabled' : null); ?> mb-2">
										<div class="input-group-text">
											<i class="bx <?php echo e(($item->actived=='0') ? 'bx' : 'text-success bxs'); ?>-message-square-edit"></i>
										</div>
										<input type="text" name="title_<?php echo e($item->type.$item->id); ?>" id="title-<?php echo e($item->type.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->type.$item->id); ?>" value="<?php echo e($item->title); ?>" data-edit="<?php echo e($item->type.$item->id); ?>" placeholder="isi disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
										<input type="text" name="content_<?php echo e($item->type.$item->id); ?>" id="content-<?php echo e($item->type.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->type.$item->id); ?>" value="<?php echo e($item->content); ?>" data-edit="<?php echo e($item->type.$item->id); ?>" placeholder="isi disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
									</div>
									<input type="radio" name="edit_<?php echo e($item->type.$item->id); ?>" id="edit-<?php echo e($item->type.$item->id); ?>" value="true">
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<div class="tab-pane fade" id="nav-<?php echo e($tablist[2]['title']); ?>" role="tabpanel">
								<?php $__currentLoopData = $contact['email']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="link-external_form border shadow rounded p-2 mb-3">
									<div class="d-flex justify-content-between py-2 px-3">
										<div>
											<i class="bx bx-envelope"></i>
											<?php echo e(Str::title('email ').($key+1)); ?>

										</div>
										<div class="form-check form-switch">
											<input class="form-check-input change-input-status change-input-edited" data-edit="<?php echo e($item->type.$item->id); ?>" type="checkbox" name="active_<?php echo e($item->type.$item->id); ?>" data-brand="<?php echo e($item->type.$item->id); ?>" value="true" <?php echo e(($item->actived=='1') ? 'checked' : null); ?>>
										</div>
									</div>
									<div class="input-group input-group-merge input-group-<?php echo e($item->type.$item->id); ?> <?php echo e(($item->actived=='0') ? 'disabled' : null); ?> mb-2">
										<div class="input-group-text">
											<i class="bx <?php echo e(($item->actived=='0') ? 'bx' : 'text-warning bxs'); ?>-message-square-edit"></i>
										</div>
										<input type="text" name="title_<?php echo e($item->type.$item->id); ?>" id="title-<?php echo e($item->type.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->type.$item->id); ?>" value="<?php echo e($item->title); ?>" data-edit="<?php echo e($item->type.$item->id); ?>" placeholder="isi disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
										<input type="email" name="content_<?php echo e($item->type.$item->id); ?>" id="content-<?php echo e($item->type.$item->id); ?>" class="form-control change-input-edited input-<?php echo e($item->type.$item->id); ?>" value="<?php echo e($item->content); ?>" data-edit="<?php echo e($item->type.$item->id); ?>" placeholder="isi disini" <?php echo e(($item->actived=='0') ? 'readonly' : null); ?>>
									</div>
									<input type="radio" name="edit_<?php echo e($item->type.$item->id); ?>" id="edit-<?php echo e($item->type.$item->id); ?>" value="true">
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/contact/index.blade.php ENDPATH**/ ?>