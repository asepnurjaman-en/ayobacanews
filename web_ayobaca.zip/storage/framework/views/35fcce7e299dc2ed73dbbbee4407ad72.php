
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body">
				<div class="row g-3">
					<div class="col-12 col-lg-8">
						<div class="form-group mb-2">
							<label for="name" class="form-label mb-1"><?php echo e(__('nama')); ?></label>
							<input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($editor->name ?? old('name')); ?>">
						</div>
						<div class="form-group mb-2">
							<label for="email" class="form-label mb-1"><?php echo e(__('email')); ?></label>
							<input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($editor->email ?? old('email')); ?>">
						</div>
						<?php if($data['form']['class']=='form-insert'): ?>
						<div class="form-group mb-2">
							<label for="password" class="form-label mb-1"><?php echo e(__('kata sandi')); ?></label>
							<input type="password" name="password" id="password" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>">
						</div>
						<div class="form-group mb-2">
							<label for="password_confirmation" class="form-label mb-1"><?php echo e(__('ulangi kata sandi')); ?></label>
							<input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>">
						</div>
						<?php endif; ?>
					</div>
					<div class="col-12 col-lg-4">
						
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('node_modules/select2/dist/js/select2.min.js')); ?>" type="text/javascript"></script>
<?php echo $__env->make('layouts.panel.storage-modal', ['mode'=>'single'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/editor/form.blade.php ENDPATH**/ ?>