<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="theme-color" content="<?php echo e($global['setting'][3]->content); ?>">
    <meta name="keywords" content="<?php echo e($global['setting'][5]->content); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css">
    <?php echo $__env->yieldPushContent('meta'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-e559bf45.css')); ?>">
    
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
    <?php echo $__env->yieldPushContent('running-text'); ?>
    <?php echo $__env->make('layouts.app-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('node_modules/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('build/assets/app-662fcc1c.js')); ?>" type="module"></script>
    <?php echo $__env->make('layouts.app-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/layouts/app.blade.php ENDPATH**/ ?>