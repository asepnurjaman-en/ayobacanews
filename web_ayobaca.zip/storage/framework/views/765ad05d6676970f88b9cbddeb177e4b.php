
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row">
                    <div class="col-12 col-md-8">
						<div class="form-group mb-3">
							<label for="name" class="form-label mb-1"><?php echo e(__('nama')); ?></label>
							<input type="text" name="name" id="name" class="form-control" placeholder="isi disini" value="<?php echo e($testimony->name ?? old('name')); ?>">
						</div>
						<div class="form-group mb-3">
							<label for="subname" class="form-label mb-1"><?php echo e(__('sub nama')); ?></label>
							<input type="text" name="subname" id="subname" class="form-control" placeholder="isi disini" value="<?php echo e($testimony->subname ?? old('subname')); ?>">
						</div>
						<div class="form-group mb-3">
							<label for="message" class="form-label mb-1"><?php echo e(__('pesan')); ?></label>
							<textarea name="message" id="message" class="form-control" placeholder="isi disini"><?php echo e($testimony->message ?? old('message')); ?></textarea>
						</div>
					</div>
					<div class="col-12 col-md-4">
						<div class="card border mb-3">
							<div class="card-body">
								<div class="form-check form-switch">
									<input class="form-check-input" type="checkbox" name="publish" id="publish" value="publish" <?php echo e(($data['form']['class']=='form-update' && $service->publish!='publish') ? null : 'checked'); ?>>
									<label class="form-check-label" for="publish"><?php echo e(Str::title('publish')); ?></label>
								</div>
							</div>
						</div>
						<div class="card border mb-3">
							<div class="card-body p-3">
								<label class="form-label" for="upload-file"><?php echo e(Str::title('foto')); ?></label>
								<div class="btn-group d-flex justify-content-between">
									<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
										<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
										<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
									</label>
									<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
										<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="<?php echo e('image' ?? old('file_type')); ?>" readonly>
								<div id="thumbail-preview">
									<?php if($data['form']['class']=='form-update'): ?>
									<div>
										<div class="item-image">
											<?php echo image(src:url('storage/sm/'.$testimony->file), alt:$testimony->file); ?>

											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4><?php echo e(Str::title('image')); ?></h4>
												<input type="hidden" name="file" value="<?php echo e($testimony->file); ?>">
											</div>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<?php echo $__env->make('layouts.panel.storage-modal', ['mode'=>'single'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/testimony/form.blade.php ENDPATH**/ ?>