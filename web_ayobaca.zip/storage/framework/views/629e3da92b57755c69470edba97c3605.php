
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="form-group d-flex align-items-center justify-content-between my-3">
		<h3 class="mb-0"><?php echo e(Str::title($data['title'])); ?></h3>
	</div>
	<div class="row g-2 hl-setup">
		<?php $__currentLoopData = $highlight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-4">
			<div id="hl-space-<?php echo e($item->id); ?>" class="bg-white shadow-sm p-1">
				<div class="hl-space border">
					<?php if($item->article && $item->article->file_type=='image'): ?>
					<?php echo image(src:url('storage/sm/'.$item->article->file), alt:$item->article->file, class:['img-fluid']); ?>

					<?php elseif($item->article && $item->article->file_type=='video'): ?>
					<?php echo image(src:url('https://img.youtube.com/vi/'.$item->article->file.'/hqdefault.jpg'), alt:$item->article->file_type, class:['img-fluid']); ?>

					<?php else: ?>
					<img src="https://www.pulsecarshalton.co.uk/wp-content/uploads/2016/08/jk-placeholder-image.jpg" alt="Pilih berita">
					<?php endif; ?>
					<div class="overlay">
						<button type="button" class="btn btn-primary btn-sm open-hl me-1" data-bs-toggle="modal" data-bs-target="#input-news-modal" data-hl-position="<?php echo e($item->id); ?>">
							Pilih berita
						</button>
					</div>
				</div>
				<div class="d-flex justify-content-between overflow-hidden my-1" style="<?php echo \Illuminate\Support\Arr::toCssStyles('height:40px') ?>">
					<span class="small lh-1"><?php echo e(($item->article) ? $item->article->title : '#'.($key + 1)); ?></span>
					<button type="button" class="btn btn-danger btn-sm close-hl" data-hl-position="<?php echo e($item->id); ?>" <?php echo e(($item->article) ? null : 'disabled'); ?>>
						<i class="bx bxs-trash"></i>
					</button>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php echo $__env->make('layouts.panel.input-news-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script>
	let csrf = $("meta[name=csrf-token]").attr('content');
	$(".open-hl").on('click', function() {
		let position = $(this).data('hl-position');
		$(".select-hl").attr('id', position);
	});
	$(document).on('click', '.select-hl', function(e) {
		e.preventDefault();
		let id = $(this).data('id'),
			image = $(this).data('image'),
			title = $(this).data('title'),
			position = $(this).attr('id');
		setTimeout(() => {
			$("#input-news-modal").modal('hide');
			$.ajax({
				type: 'post',
				url : `<?php echo e(route('article.highlight.update')); ?>`,
				data: {
					_token: csrf, _method: 'PUT', id: position, article_id: id
				},
				dataType: 'json',
				error: function(q,w,e) {
				},
				success: function(response) {
					$("#hl-space-"+position).find('.hl-space').find('img').attr('src', image);
					$("#hl-space-"+position).find('span').text(title);
					$("#hl-space-"+position).find('.close-hl').prop('disabled', false);
				}
			});
		}, 200);
	});
	$(document).on('click', '.close-hl', function(e) {
		let position = $(this).data('hl-position');
		$.ajax({
			type: 'post',
			url : `<?php echo e(route('article.highlight.update')); ?>`,
			data: {
				_token: csrf, _method: 'PUT', id: position, article_id: 0
			},
			dataType: 'json',
			error: function(q,w,e) {
			},
			success: function(response) {
				$(this).prop('disabled', true);
				$("#hl-space-"+position).find('.hl-space').children('img').attr('src', null);
				$("#hl-space-"+position).find('span').text(null);
			}
		});
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/panel/article/highlight.blade.php ENDPATH**/ ?>