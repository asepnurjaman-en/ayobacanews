
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-3">
							<label for="title" class="form-label mb-1"><?php echo e(__('judul')); ?></label>
							<input type="text" name="title" id="title" class="form-control form-control-lg counting-input" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($gallery->title ?? old('title')); ?>" maxlength="110">
							<ul class="list-unstyled small">
								<li><span class="counting fw-bold"><?php echo e(strlen($gallery->title ?? null)); ?></span>/110</li>
							</ul>
						</div>
					</div>
					<div class="col-12 col-md-8">
						<div class="form-group mb-3">
							<label for="content" class="form-label mb-1"><?php echo e(__('deskripsi')); ?></label>
							<textarea name="content" id="content" class="form-control" placeholder="isi disini"><?php echo e($gallery->content ?? old('content')); ?></textarea>
						</div>
						<div class="form-check form-switch mb-2">
							<input class="form-check-input" type="checkbox" id="grouped" name="grouped" value="true" <?php echo e(($data['form']['class']=='form-update' && $gallery->grouped=='1') ? 'checked' : null); ?>>
							<label class="form-check-label" for="grouped">Buat Album</label>
						</div>
						<div id="grouped-alert" class="alert alert-info  <?php echo e(($data['form']['class']=='form-update' && $gallery->grouped=='1') ? null : 'd-none'); ?>" role="alert">
							<i class="bx bx-info-circle"></i>
							<b>Disimpan sebagai album.</b>
							<p><?php echo e(__('Menambahkan foto pada album tersedia setelah album disimpan.')); ?></p>
						</div>
					</div>
					<div class="col-12 col-md-4">
						<div class="card border mb-3">
							<div class="card-body p-3">
								<label class="form-label" for="upload-file"><?php echo e(Str::title('thumbnail')); ?></label>
								<div class="btn-group d-flex justify-content-between">
									<button type="button" class="btn btn-outline-danger change-file-type" data-bs-toggle="modal" data-bs-target="#input-youtube-modal" data-file-type="video">
										<i class="bx bxl-youtube" data-bs-toggle="tooltip" data-bs-original-title="Tautan Youtube" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="<?php echo e('video' ?? old('file_type')); ?>" readonly>
								<div id="thumbail-preview">
									<?php if($data['form']['class']=='form-update'): ?>
									<div>
										<div class="item-image">
											<?php echo image(src:url('https://img.youtube.com/vi/'.$gallery->file.'/hqdefault.jpg'), alt:$gallery->type); ?>

											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4><?php echo e(Str::title($gallery->file)); ?></h4>
												<input type="hidden" name="file" value="<?php echo e($gallery->file); ?>">
											</div>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php echo $__env->make('layouts.panel.input-youtube-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/gallery/form-video.blade.php ENDPATH**/ ?>