<?php
    $content = json_decode($feedback->content, true);
?>

<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-12">
			<div class="my-3 mb-0">
				<button type="button" class="btn-back btn btn-outline-secondary">
                    <i class="bx bx-chevron-left"></i>
                    <span><?php echo e(Str::title('kembali')); ?></span>
                </button>
			</div>
			<div class="card border-0 my-3">
                <div class="card-header border-bottom px-3 py-2">
                    <span>Dari: <b><?php echo e($feedback->name); ?></b></span>
                </div>
				<div class="card-body p-3">
                    <div class="d-flex justify-content-between flex-column flex-md-row">
                        <ul class="list-unstyled">
                            <li><?php echo e($feedback->phone); ?></li>
                            <li><?php echo e($feedback->email); ?></li>
                        </ul>
                        <ul class="list-unstyled">
                            <li><?php echo e(date('Y/m/d', strtotime($feedback->created_at))); ?></li>
                            <li><?php echo e(date('H:i', strtotime($feedback->created_at))); ?></li>
                        </ul>
                    </div>					
                    <blockquote class="bg-body p-3">
                        <span class="fs-5 fw-bold"><?php echo e($content[0]['subject']); ?></span>
                        <div><?php echo e($content[0]['message']); ?></div>
                    </blockquote>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/feedback/show.blade.php ENDPATH**/ ?>