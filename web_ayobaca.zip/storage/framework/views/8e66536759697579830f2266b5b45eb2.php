
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-12">
			<form action="<?php echo e($data['delete']['action']); ?>" method="post" class="form-delete my-3 mb-0" data-message="<?php echo e($data['delete']['message']); ?>">
				<?php echo method_field('DELETE'); ?>
				<input type="hidden" name="id_delete" value/>
				<a href="<?php echo e($data['create']['action']); ?>" class="btn btn-success">
					<i class="bx bx-plus"></i>
					<span><?php echo e(Str::title('tambah baru')); ?></span>
				</a>
				<button type="submit" class="btn btn-danger" disabled>
					<i class="bx bx-trash"></i>
					<span><?php echo e(Str::title('hapus')); ?></span>
					<b></b>
				</button>
			</form>
			<div class="card border-0 my-3">
				<div class="card-body p-0">
					<table class="dataTables" data-list="<?php echo e($data['list']); ?>">
						<thead>
							<tr>
								<th><i class="bx bx-cog"></i></th>
								<th></th>
								<th></th>
								<th></th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('node_modules/datatable/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
	<script src="<?php echo e(asset('node_modules/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.panel.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\learn\origin1\C\resources\views/panel/testimony/index.blade.php ENDPATH**/ ?>