
<?php $__env->startSection('title', Str::title($data['title'])); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e($data['form']['action']); ?>" method="post" enctype="multipart/form-data" class="<?php echo e($data['form']['class']); ?> my-3">
		<?php echo csrf_field(); ?>
		<?php if($data['form']['class']=='form-update'): ?>
			<?php echo method_field('PATCH'); ?>
		<?php endif; ?>
		<div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span><?php echo e(Str::title('kembali')); ?></span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span><?php echo e(Str::title('simpan')); ?></span>
					</button>
				</div>
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-2">
							<label for="title" class="form-label mb-1"><?php echo e(__('judul')); ?></label>
							<input type="text" name="title" id="title" class="form-control" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($article_category->title ?? old('title')); ?>">
						</div>
					</div>
					<div class="form-group mb-2">
						<label for="color" class="form-label mb-1"><?php echo e(__('warna')); ?></label>
						<input type="color" name="color" id="color" class="form-color" placeholder="<?php echo e(__('isi disini')); ?>" value="<?php echo e($article_category->color ?? old('color')); ?>">
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.editor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_ayobaca\resources\views/editor/article/form-category.blade.php ENDPATH**/ ?>