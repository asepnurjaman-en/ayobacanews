@extends('layouts.editor.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<form action="{{ $data['form']['action'] }}" method="post" enctype="multipart/form-data" class="{{ $data['form']['class'] }} my-3">
		@csrf
		@if ($data['form']['class']=='form-update')
			@method('PATCH')
		@endif
		<div class="form-group">
			<label for="title" class="form-label mb-1">{{ __('judul berita') }}</label>
			<input type="text" name="title" id="title" class="form-control form-control-lg counting-input" placeholder="isi disini" value="{{ $article->title ?? old('title') }}" maxlength="110">
			<ul class="list-unstyled small">
				<li><span class="counting fw-bold">{{ strlen($article->title ?? null) }}</span>/110</li>
			</ul>
		</div>
		<div class="my-1">
			<div>
				<div class="row g-2">
					<div class="col-12 col-lg-8">
						<div class="sticky-top">
							<textarea name="content" id="content" class="mce">{{ $article->content ?? old('content') }}</textarea>
						</div>
					</div>
					<div class="col-12 col-lg-4">
						<button type="submit" class="btn btn-primary w-100" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
							<i class="bx bx-save"></i>
							<span>{{ Str::title('simpan') }}</span>
						</button>
						<div class="card border mt-2 mb-2">
							<div class="card-body p-3">
								@foreach (['draft'=>'draft', 'publish'=>'rilis', 'schedule'=>'dijadwalkan'] as $key => $val)
								<div class="form-check">
									<input class="form-check-input" type="radio" name="publish" id="{{ $key }}" value="{{ $key }}" @checked($article->publish==$key)>
									<label class="form-check-label" for="{{ $key }}">{{ Str::title($val) }}</label>
								</div>
								@endforeach
							</div>
							<div id="scheduled" class="card-body border-top p-3 {{ (!in_array($article->publish, ['schedule'])) ? 'd-none' : null }}">
								<input type="date" name="schedule_date" id="schedule_date" class="form-control mb-2" placeholder="isi disini" value="{{ ($data['form']['class']=='form-update' && !empty($article->schedule_time)) ? date('Y-m-d', strtotime($article->schedule_time)) : date('Y-m-d') }}">
								<input type="time" name="schedule_time" id="schedule_time" class="form-control" placeholder="isi disini" value="{{ ($data['form']['class']=='form-update' && !empty($article->schedule_time)) ? date('H:i', strtotime($article->schedule_time)) : date('H:i') }}">
							</div>
						</div>
						<div class="card border mb-2">
							<div class="card-body p-3">
								<label class="form-label" for="upload-file">{{ Str::title('thumbnail') }}</label>
								<div class="btn-group d-flex justify-content-between">
									<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
										<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
										<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
									</label>
									<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
										<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
									</button>
									<button type="button" class="btn btn-outline-danger border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#input-youtube-modal" data-file-type="video">
										<i class="bx bxl-youtube" data-bs-toggle="tooltip" data-bs-original-title="Tautan Youtube" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="{{ $article->file_type ?? old('file_type') }}" readonly>
								<div id="thumbail-preview" class="mb-2">
									@if ($data['form']['class']=='form-update')
									<div>
										<div class="item-image">
											@if ($article->file_type=='image')
											{!! image(src:url('storage/sm/'.$article->file), alt:$article->file) !!}
											@elseif ($article->file_type=='video')
											{!! image(src:url('https://img.youtube.com/vi/'.$article->file.'/hqdefault.jpg'), alt:$article->file_type) !!}
											@endif
											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4>{{ Str::title($article->file_type) }}</h4>
												<input type="hidden" name="file" value="{{ $article->file }}">
											</div>
										</div>
									</div>
									@endif
								</div>
								<textarea name="file_source" id="file_source" class="form-control" placeholder="Keterangan">{{ $article->file_source ?? old('file_source') }}</textarea>
							</div>
						</div>
						<div id="articleAssets" class="accordion">
							<div class="accordion-item card">
							  	<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_article_category_id" aria-controls="accor_article_category_id" aria-expanded="false">Kategori</button>
							  	</h2>
								<div id="accor_article_category_id" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<select name="article_category_id" id="article_category_id" class="form-control select2 w-100">
											@forelse ($article_category as $item)
											<option value="{{ $item->id }}" {{ ($data['form']['class']=='form-update' && $article->article_category_id==$item->id) ? 'selected' : null }}>{{ $item->title }}</option>
											@empty
											<option>{{ __('empty') }}</option>
											@endforelse
										</select>
									</div>
								</div>
							</div>
		
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_date" aria-controls="accor_date" aria-expanded="false">Waktu &amp; tanggal</button>
								</h2>
								<div id="accor_date" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<input type="date" name="date" id="date" class="form-control mb-2" placeholder="isi disini" value="{{ ($data['form']['class']=='form-update' && !empty($article->datetime)) ? date('Y-m-d', strtotime($article->datetime)) : date('Y-m-d') }}">
										<input type="time" name="time" id="time" class="form-control" placeholder="isi disini" value="{{ ($data['form']['class']=='form-update' && !empty($article->datetime)) ? date('H:i', strtotime($article->datetime)) : date('H:i') }}">	
									</div>
								</div>
							</div>
		
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_tag" aria-expanded="false" aria-controls="accor_tag"><b class="badge bg-primary me-1">{{ count($article->tags) }}</b>Tag</button>
								</h2>
								<div id="accor_tag" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<div class="input-group">
											<input type="text" id="tags" class="form-control tag-input" placeholder="isi disini" value="{{ old('tags') }}">
											<button type="button" class="btn btn-dark tag-button" data-bs-toggle="tooltip" data-bs-original-title="Tambah topik" data-bs-placement="bottom">
												<i class="bx bx-bookmark-plus"></i>
											</button>
										</div>
										<div id="tag-preview">
											@if ($data['form']['class']=='form-update' && $article->tags!='null')
												@foreach ($article->tags as $tag)
												<span class="badge bg-primary mt-1 me-1"><i class="bx bx-x text-danger cursor-pointer me-1 tag-remove"></i>{{ $tag }}<input type="hidden" name="tags[]" value="{{ $tag }}"></span>
												@endforeach
											@endif
										</div>
									</div>
								</div>
							</div>
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_author" aria-expanded="false" aria-controls="accor_author">Penulis</button>
								</h2>
								<div id="accor_author" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<input type="text" name="author" id="author" class="form-control" placeholder="isi disini" value="{{ $article->author ?? old('author') }}">
									</div>
								</div>
							</div>
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_description" aria-controls="accor_description" aria-expanded="true">Deskripsi singkat</button>
								</h2>
								<div id="accor_description" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
									<div class="accordion-body">
										<textarea name="description" id="description" class="form-control" placeholder="isi disini">{{ $article->description ?? old('description') }}</textarea>
									</div>
								</div>
							</div>
							<div class="accordion-item card">
								<h2 class="accordion-header text-body d-flex justify-content-between">
									<button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accor_related" aria-controls="accor_related" aria-expanded="false"><b class="badge bg-primary me-1">{{ count($article_related) }}</b>Berita terkait</button>
								</h2>
							  <div id="accor_related" class="accordion-collapse collapse" data-bs-parent="#articleAssets">
								  <div class="accordion-body">
										<select name="related[]" id="related" class="form-control select2-news w-100" multiple data-url="{{ route('ae.article.option') }}">
											@foreach ($article_related as $item)
											<option value="{{ $item->id }}" @selected(true)>{{ $item->title }}</option>
											@endforeach
										</select>
								  </div>
							  </div>
						  </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
@endsection

@push('style')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ asset('node_modules/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('node_modules/select2/dist/css/select2.min.css') }}">
@endpush

@push('script')
<script src="{{ asset('node_modules/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('node_modules/select2/dist/js/select2.min.js') }}" type="text/javascript"></script>
<script src="https://cdn.tiny.cloud/1/9itgriy90vlqq8utp58vwdgdp06frez49d36w3lv684grblh/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
@include('layouts.panel.storage-modal', ['mode'=>'single'])
@include('layouts.panel.input-youtube-modal')
<script>
	$("input[name=publish]").on('change', function(e) {
		if (e.target.value=='schedule') {
			$("#scheduled").removeClass('d-none');
		} else {
			$("#scheduled").addClass('d-none');
		}
	})
</script>
@endpush