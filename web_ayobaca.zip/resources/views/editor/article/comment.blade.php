@extends('layouts.editor.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<div class="form-group mt-3">
		<div class="input-group bg-white rounded">
			<button type="button" class="btn-back btn btn-outline-secondary">
				<i class="bx bx-chevron-left"></i>
				<span>{{ Str::title('kembali') }}</span>
			</button>
			<input type="text" name="title" id="title" class="form-control bg-white" placeholder="isi disini" value="{{ $article->title ?? old('title') }}" maxlength="110" disabled>
		</div>
	</div>
	<div class="my-1">
		<div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<h4 class="mb-0">Kelola komentar</h4>
				</div>
			</div>
			<div class="card-body">
				@forelse ($article->comment as $item)
				<div class="row g-2 align-items-center border-bottom mb-2">
					<div class="col-lg-8">
						<div class="comment">
							<div class="image">
								<img src="{{ $item->user->avatar }}" alt="">
								<div class="name">
									<b>{{ $item->user->name }}</b>
									<small class="text-muted">{{ date_stat($item->created_at) }}</small>
								</div>
							</div>
							<blockquote>{{ $item->comment }}</blockquote>
						</div>
					</div>
					<div class="col-lg-4">
						<form action="{{ route('article.comment.delete', $item->id) }}" method="post" class="p-2">
							@csrf
							@method('DELETE')
							@if ($item->publish!='publish')
							<a href="{{ route('article.comment.update', $item->id) }}" class="btn btn-success btn-sm">
								<i class="bx bx-check"></i>
								<span>Setujui</span>
							</a>
							@else
							<span class="btn btn-secondary btn-sm disabled">
								<i class="bx bx-check"></i>
								<span>Setujui</span>
							</span>
							@endif
							<button type="submit" class="btn btn-danger btn-sm">
								<i class="bx bx-x"></i>
								<span>{{ Str::title('buang') }}</span>
								<b></b>
							</button>
						</form>
					</div>
				</div>
				@empty
				<div class="text-center">Belum ada komentar</div>
				@endforelse
			</div>
		</div>
	</div>
</div>
@endsection

@push('style')
	<meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@push('script')
@endpush