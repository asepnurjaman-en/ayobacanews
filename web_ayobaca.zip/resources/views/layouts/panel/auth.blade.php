<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>
	<title>@yield('title')</title>
	{{-- Links --}}
	{{-- <link rel="stylesheet" href="{{ asset('node_modules/boxicons/css/boxicons.min.css') }}"> --}}
	{{-- <link rel="stylesheet" href="{{ asset('sneat/css/core.css') }}"> --}}
	{{-- <link rel="stylesheet" href="{{ asset('sneat/css/theme-default.css') }}"> --}}
	<link rel="shortcut icon" href="{{ url('sneat/img/favicon.png') }}" type="image/x-icon">
    {{-- <script src="{{ asset('sneat/js/helpers.js') }}"></script> --}}
	{{-- @vite(['resources/css/sneat-auth.css']) --}}
	<link rel="stylesheet" href="{{ asset('build/assets/sneat-auth-46a799e1.css') }}">
</head>
<body>
	<div class="container-xxl">
		<div class="authentication-wrapper authentication-basic container-p-y">
			<div class="authentication-inner">
				@yield('content')
			</div>
		</div>
		<div class="layout-overlay layout-menu-toggle"></div>
	</div>
	{{-- Scripts --}}
    <script src="{{ asset('node_modules/jquery/dist/jquery.min.js') }}"></script>
    {{-- <script src="{{ asset('sneat/js/main.js') }}"></script> --}}
	{{-- @vite(['resources/js/sneat-auth.js']) --}}
	<script src="{{ asset('build/assets/sneat-auth-81bcc06d.js') }}" type="module"></script>
</body>
</html>