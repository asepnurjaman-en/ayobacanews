@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
    <div class="form-group d-flex justify-content-between mt-3">
        <button type="button" class="btn-back btn btn-outline-secondary">
            <i class="bx bx-chevron-left"></i>
            <span>{{ Str::title('kembali') }}</span>
        </button>
    </div>
    <div class="card border-0 my-3">
        <h5 class="card-header">Kelola iklan</h5>
        <div class="card-body">
            <div class="row g-w">
                <div class="col-lg-6">
                    <div class="list-group">
                        <a href="{{ route('article.ad.tp', 'home-ad') }}" class="list-group-item list-group-item-action">Beranda</a>
                        @foreach ($category as $item)
                        <a href="{{ route('article-category.ad', $item->id) }}" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            {{ $item->title }}
                            <span class="badge bg-secondary">{{ $item->articles_count }} Berita</span>
                        </a>
                        @endforeach
                        <a href="{{ route('article.ad.tp', 'contact-ad') }}" class="list-group-item list-group-item-action">Kontak</a>
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>
@endsection

@push('style')
	<meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@push('script')
@endpush