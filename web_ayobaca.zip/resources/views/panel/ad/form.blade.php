@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<form action="{{ $data['form']['action'] }}" method="post" enctype="multipart/form-data" class="{{ $data['form']['class'] }} my-3">
		@csrf
		@if ($data['form']['class']=='form-update')
			@method('PATCH')
		@endif
        <div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span>{{ Str::title('kembali') }}</span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span>{{ Str::title('simpan') }}</span>
					</button>
				</div>
			</div>
			<div class="card-body">
				<div class="row g-3">
					<div class="col-12 col-lg-8">
                        <div class="form-group mb-2">
                            <label for="title" class="form-label mb-1">{{ __('judul') }}</label>
							<input type="text" name="title" id="title" class="form-control" placeholder="{{ __('isi disini') }}" value="{{ $ad->title ?? old('title') }}">
						</div>
                        <div class="form-group mb-2">
                            <label for="url" class="form-label mb-1">{{ __('url') }}</label>
                            <input type="url" name="url" id="url" class="form-control" placeholder="{{ __('isi disini') }}" value="{{ $ad->url ?? old('url') }}">
                        </div>
					</div>
                    <div class="col-12 col-lg-4">
                        <div class="card mb-2">
							<div class="card-body p-3">
								<label class="form-label" for="upload-file">{{ Str::title('gambar iklan') }}</label>
								<div class="btn-group d-flex justify-content-between">
									<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
										<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
										<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
									</label>
									<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
										<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="image" readonly>
								<div id="thumbail-preview" class="mb-2">
									@if ($data['form']['class']=='form-update')
									<div>
										<div class="item-image">
											{!! image(src:url('storage/sm/'.$ad->file), alt:$ad->file) !!}
											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4>{{ Str::title($ad->title) }}</h4>
												<input type="hidden" name="file" value="{{ $ad->file }}">
											</div>
										</div>
									</div>
									@endif
								</div>
							</div>
						</div>
                    </div>
				</div>
			</div>
		</div>
	</form>
</div>
@endsection

@push('style')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ asset('node_modules/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('node_modules/select2/dist/css/select2.min.css') }}">
@endpush

@push('script')
<script src="{{ asset('node_modules/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('node_modules/select2/dist/js/select2.min.js') }}" type="text/javascript"></script>
@include('layouts.panel.storage-modal', ['mode'=>'single'])
@endpush