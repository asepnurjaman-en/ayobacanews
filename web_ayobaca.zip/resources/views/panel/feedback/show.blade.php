@php
    $content = json_decode($feedback->content, true);
@endphp
@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<div class="row">
		<div class="col-12">
			<div class="my-3 mb-0">
				<button type="button" class="btn-back btn btn-outline-secondary">
                    <i class="bx bx-chevron-left"></i>
                    <span>{{ Str::title('kembali') }}</span>
                </button>
			</div>
			<div class="card border-0 my-3">
                <div class="card-header border-bottom p-3">
                    <span>Dari: <b>{{ $feedback->name }}</b></span>
                </div>
				<div class="card-body p-3">
                    <div class="d-flex justify-content-between flex-column flex-md-row">
                        <ul class="list-unstyled">
                            <li>{{ $feedback->phone }}</li>
                            <li>{{ $feedback->email }}</li>
                        </ul>
                        <ul class="list-unstyled">
                            <li>{{ date('Y/m/d', strtotime($feedback->created_at)) }}</li>
                            <li>{{ date('H:i', strtotime($feedback->created_at)) }}</li>
                        </ul>
                    </div>					
                    <blockquote class="bg-body p-3">
                        <span class="fs-5 fw-bold">{{ $content[0]['subject'] }}</span>
                        <div>{{ $content[0]['message'] }}</div>
                    </blockquote>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@push('style')
	<meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@push('script')
@endpush