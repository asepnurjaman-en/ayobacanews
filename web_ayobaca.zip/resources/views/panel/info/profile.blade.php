@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<form action="{{ $data['form']['action'] }}" method="post" enctype="multipart/form-data" class="{{ $data['form']['class'] }} my-3">
		@csrf
		@method('PATCH')
		<div class="card border-0 my-3">
			<div class="card-header p-3">
				<div class="form-group d-flex justify-content-between">
					<h3 class="mb-0">{{ Str::title($data['title']) }}</h3>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span>{{ Str::title('simpan') }}</span>
					</button>
				</div>
			</div>
			<div class="card-body p-3">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-3">
							<label for="title" class="form-label mb-1">{{ __('judul') }}</label>
							<input type="text" name="title" id="title" class="form-control form-control-lg counting-input" placeholder="{{ __('isi disini') }}" value="{{ $profile->title ?? old('title') }}" maxlength="110">
							<ul class="list-unstyled small">
								<li><span class="counting fw-bold">{{ strlen($profile->title ?? null) }}</span>/110</li>
							</ul>
						</div>
					</div>
					<div class="col-12 col-md-8">
						<div class="form-group mb-3">
							<textarea name="content" id="content" class="mce" placeholder="isi disini">{{ $profile->content ?? old('content') }}</textarea>
						</div>
					</div>
					<div class="col-12 col-md-4">
						<div class="card border mb-3">
							<div class="card-body">
								<label class="form-label" for="upload-file">{{ Str::title('thumbnail') }}</label>
								<div class="btn-group d-flex justify-content-between">
									<label for="upload-file" class="btn btn-outline-primary change-file-type" data-file-type="upload-file">
										<i class="bx bx-upload" data-bs-toggle="tooltip" data-bs-original-title="Unggah Foto" data-bs-placement="bottom"></i>
										<input type="file" name="upload_file" id="upload-file" class="choose-image" hidden="" accept="image/png, image/jpeg">
									</label>
									<button type="button" class="btn btn-outline-info border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#single-storage-modal" data-file-type="image">
										<i class="bx bx-image" data-bs-toggle="tooltip" data-bs-original-title="Buka Penyimpanan" data-bs-placement="bottom"></i>
									</button>
									<button type="button" class="btn btn-outline-danger border-start-0 change-file-type" data-bs-toggle="modal" data-bs-target="#input-youtube-modal" data-file-type="video">
										<i class="bx bxl-youtube" data-bs-toggle="tooltip" data-bs-original-title="Tautan Youtube" data-bs-placement="bottom"></i>
									</button>
								</div>
								<input type="hidden" name="file_type" id="input-file-type" value="{{ $profile->file_type ?? old('file_type') }}" readonly>
								<div id="thumbail-preview">
									@if ($data['form']['class']=='form-update')
									<div>
										<div class="item-image">
											@if ($profile->file_type=='image')
											{!! image(src:url('storage/'.$profile->file), alt:$profile->file) !!}
											@elseif ($profile->file_type=='video')
											{!! image(src:url('https://img.youtube.com/vi/'.$profile->file.'/hqdefault.jpg'), alt:$profile->file_type) !!}
											@endif
											<div class="overlay">
												<button title="button" class="remove unchoose-image">&times;</button>
												<h4>{{ Str::title($profile->file_type) }}</h4>
												<input type="hidden" name="file" value="{{ $profile->file }}">
											</div>
										</div>
									</div>
									@endif
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
@endsection

@push('style')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ asset('node_modules/datatable/datatables.min.css') }}">
@endpush

@push('script')
<script src="{{ asset('node_modules/datatable/datatables.min.js') }}"></script>
<script src="https://cdn.tiny.cloud/1/9itgriy90vlqq8utp58vwdgdp06frez49d36w3lv684grblh/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
@include('layouts.panel.storage-modal', ['mode'=>'single'])
@include('layouts.panel.input-youtube-modal')
@endpush