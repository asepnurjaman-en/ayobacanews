@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<form action="{{ $data['form']['action'] }}" method="post" class="{{ $data['form']['class'] }} my-3">
		@csrf
		@if ($data['form']['class']=='form-update')
			@method('PATCH')
		@endif
		<div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span>{{ Str::title('kembali') }}</span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span>{{ Str::title('simpan') }}</span>
					</button>
				</div>
			</div>
			<div class="card-body">
				<div class="row g-3">
					<div class="col-12 col-lg-8">
						<div class="form-group mb-2">
							<label for="name" class="form-label mb-1">{{ __('nama') }}</label>
							<input type="text" name="name" id="name" class="form-control" placeholder="{{ __('isi disini') }}" value="{{ $editor->name ?? old('name') }}">
						</div>
						<div class="form-group mb-2">
							<label for="email" class="form-label mb-1">{{ __('email') }}</label>
							<input type="email" name="email" id="email" class="form-control" placeholder="{{ __('isi disini') }}" value="{{ $editor->email ?? old('email') }}">
						</div>
						@if ($data['form']['class']=='form-insert')
						<div class="form-group mb-2">
							<label for="password" class="form-label mb-1">{{ __('kata sandi') }}</label>
							<input type="password" name="password" id="password" class="form-control" placeholder="{{ __('isi disini') }}">
						</div>
						<div class="form-group mb-2">
							<label for="password_confirmation" class="form-label mb-1">{{ __('ulangi kata sandi') }}</label>
							<input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="{{ __('isi disini') }}">
						</div>
						@endif
					</div>
					<div class="col-12 col-lg-4">
						
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
@endsection

@push('style')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ asset('node_modules/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('node_modules/select2/dist/css/select2.min.css') }}">
@endpush

@push('script')
<script src="{{ asset('node_modules/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('node_modules/select2/dist/js/select2.min.js') }}" type="text/javascript"></script>
@include('layouts.panel.storage-modal', ['mode'=>'single'])
@endpush