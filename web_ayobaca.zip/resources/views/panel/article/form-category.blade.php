@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<form action="{{ $data['form']['action'] }}" method="post" enctype="multipart/form-data" class="{{ $data['form']['class'] }} my-3">
		@csrf
		@if ($data['form']['class']=='form-update')
			@method('PATCH')
		@endif
		<div class="card border-0 my-3">
			<div class="card-header">
				<div class="form-group d-flex justify-content-between">
					<button type="button" class="btn-back btn btn-outline-secondary">
						<i class="bx bx-chevron-left"></i>
						<span>{{ Str::title('kembali') }}</span>
					</button>
					<button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-original-title="CTRL + S" data-bs-placement="bottom">
						<i class="bx bx-save"></i>
						<span>{{ Str::title('simpan') }}</span>
					</button>
				</div>
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-12">
						<div class="form-group mb-2">
							<label for="title" class="form-label mb-1">{{ __('judul') }}</label>
							<input type="text" name="title" id="title" class="form-control" placeholder="{{ __('isi disini') }}" value="{{ $article_category->title ?? old('title') }}">
						</div>
					</div>
					<div class="form-group mb-2">
						<label for="color" class="form-label mb-1">{{ __('warna') }}</label>
						<input type="color" name="color" id="color" class="form-color" placeholder="{{ __('isi disini') }}" value="{{ $article_category->color ?? old('color') }}">
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
@endsection

@push('style')
	<meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@push('script')
@endpush