@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<div class="form-group d-flex align-items-center justify-content-between my-3">
		<h3 class="mb-0">{{ Str::title($data['title']) }}</h3>
	</div>
	<div class="row g-2 hl-setup">
		@foreach ($highlight as $key => $item)
		<div class="col-4">
			<div id="hl-space-{{ $item->id }}" class="bg-white shadow-sm p-1">
				<div class="hl-space border">
					@if ($item->article && $item->article->file_type=='image')
					{!! image(src:url('storage/sm/'.$item->article->file), alt:$item->article->file, class:['img-fluid']) !!}
					@elseif ($item->article && $item->article->file_type=='video')
					{!! image(src:url('https://img.youtube.com/vi/'.$item->article->file.'/hqdefault.jpg'), alt:$item->article->file_type, class:['img-fluid']) !!}
					@else
					<img src="https://www.pulsecarshalton.co.uk/wp-content/uploads/2016/08/jk-placeholder-image.jpg" alt="Pilih berita">
					@endif
					<div class="overlay">
						<button type="button" class="btn btn-primary btn-sm open-hl me-1" data-bs-toggle="modal" data-bs-target="#input-news-modal" data-hl-position="{{ $item->id }}">
							Pilih berita
						</button>
					</div>
				</div>
				<div class="d-flex justify-content-between overflow-hidden my-1" @style('height:40px')>
					<span class="small lh-1">{{ ($item->article) ? $item->article->title : '#'.($key + 1) }}</span>
					<button type="button" class="btn btn-danger btn-sm close-hl" data-hl-position="{{ $item->id }}" {{ ($item->article) ? null : 'disabled' }}>
						<i class="bx bxs-trash"></i>
					</button>
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>
@endsection

@push('style')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ asset('node_modules/datatable/datatables.min.css') }}">
@endpush

@push('script')
@include('layouts.panel.input-news-modal')
<script src="{{ asset('node_modules/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script>
	let csrf = $("meta[name=csrf-token]").attr('content');
	$(".open-hl").on('click', function() {
		let position = $(this).data('hl-position');
		$(".select-hl").attr('id', position);
	});
	$(document).on('click', '.select-hl', function(e) {
		e.preventDefault();
		let id = $(this).data('id'),
			image = $(this).data('image'),
			title = $(this).data('title'),
			position = $(this).attr('id');
		setTimeout(() => {
			$("#input-news-modal").modal('hide');
			$.ajax({
				type: 'post',
				url : `{{ route('article.highlight.update') }}`,
				data: {
					_token: csrf, _method: 'PUT', id: position, article_id: id
				},
				dataType: 'json',
				error: function(q,w,e) {
				},
				success: function(response) {
					$("#hl-space-"+position).find('.hl-space').find('img').attr('src', image);
					$("#hl-space-"+position).find('span').text(title);
					$("#hl-space-"+position).find('.close-hl').prop('disabled', false);
				}
			});
		}, 200);
	});
	$(document).on('click', '.close-hl', function(e) {
		let position = $(this).data('hl-position');
		$.ajax({
			type: 'post',
			url : `{{ route('article.highlight.update') }}`,
			data: {
				_token: csrf, _method: 'PUT', id: position, article_id: 0
			},
			dataType: 'json',
			error: function(q,w,e) {
			},
			success: function(response) {
				$(this).prop('disabled', true);
				$("#hl-space-"+position).find('.hl-space').children('img').attr('src', null);
				$("#hl-space-"+position).find('span').text(null);
			}
		});
	});
</script>
@endpush