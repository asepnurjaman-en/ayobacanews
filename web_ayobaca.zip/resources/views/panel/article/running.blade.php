@extends('layouts.panel.app')
@section('title', Str::title($data['title']))
@section('content')
<div class="container">
	<div class="card border-0 mt-3 mb-3">
		<div class="card-body">
			<form action="{{ $data['form']['action'] }}" method="post" enctype="multipart/form-data" class="{{ $data['form']['class'] }} my-3">
				@csrf
				@if ($data['form']['class']=='form-update')
					@method('PATCH')
				@endif
				<div class="row g-2">
					<div class="col-12 col-lg-9">
						<select name="news" id="news" class="form-control form-control-lg select2-news w-100" data-url="{{ route('article.option') }}">
						</select>
					</div>
					<div class="col-12 col-lg-3">
						<button type="submit" class="btn btn-primary w-100 dont-fixit">
							<i class="bx bx-plus"></i>
							<span>{{ Str::title('simpan') }}</span>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	@foreach ($article as $key => $item)
	<div class="mb-3">
		<div class="input-group rounded shadow">
			<span class="input-group-text fw-bold">{{ $key + 1 }}</span>
			<input type="text" class="form-control bg-white border-start-0" value="{{ $item->article->title }}" @readonly(true)>
			<a href="{{ route('article.running.delete', $item->id) }}" class="btn btn-danger">
				<i class="bx bx-x"></i>
			</a>
		</div>
	</div>
	@endforeach
</div>
@endsection

@push('style')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{ asset('node_modules/select2/dist/css/select2.min.css') }}">
@endpush

@push('script')
<script src="{{ asset('node_modules/select2/dist/js/select2.min.js') }}" type="text/javascript"></script>
@endpush