"use strict";

const Toast = Swal.mixin({
	toast: true,
	position: 'top-end',
	showConfirmButton: false,
	timer: 5000,
	timerProgressBar: true,
	didOpen: (toast) => {
		toast.addEventListener('mouseenter', Swal.stopTimer)
		toast.addEventListener('mouseleave', Swal.resumeTimer)
	}
});
const SwalDelete = Swal.mixin({
	title: 'Buang data?',
	icon: 'question',
	showCancelButton: true,
	confirmButtonText: 'Ya, buang!',
	cancelButtonText: 'Batal',
	reverseButtons: true,
	customClass: {
		confirmButton: 'btn btn-danger mx-1',
		cancelButton: 'btn btn-light mx-1'
	},
	buttonsStyling: false,
	allowOutsideClick: false,
});

function imageEl(title, file, url, mode = 'single') {
	var imageElement = `<div class="item-image">`;
		imageElement += `<img src="${url}" alt="${title}">`;
		imageElement += `<div class="overlay">`;
		imageElement += `<button title="button" class="remove unchoose-image">&times;</button>`;
		imageElement += `<h4>${title}</h4>`;
		if (mode=='single') {
			imageElement += `<input type="hidden" name="file" value="${file}">`;
		} else if (mode=='multiple') {
			imageElement += `<input type="hidden" name="files[]" value="${file}">`;
		}
		imageElement += `</div>`;
		imageElement += `</div>`;

	return imageElement;
};


$(document).on('change', '.check-row', function() {
	let id_row = [];
	$(".check-row:checked").each(function(i){
		id_row[i] = $(this).val();
	});
	if ($(this).prop('checked')) {
		$(this).parent().parent().addClass('checked');		
	} else {
		$(this).parent().parent().removeClass('checked');
	}
	if (id_row.length > 0) {
		$(".form-delete input[name=id_delete]").val(id_row);
		$(".form-delete button").prop('disabled', false);
		$(".form-delete button").children('b').text(id_row.length);
	} else {
		$(".form-delete input[name=id_delete]").val(null);
		$(".form-delete button").prop('disabled', true);
		$(".form-delete button").children('b').text(null);
	}
});

$(document).on('change', '.check-image', function() {
	let id_row = [];
	$(".check-image:checked").each(function(i){
		id_row[i] = $(this).val();
	});
	if (id_row.length > 0) {
		$(".choose-images input[name=id_image]").val(id_row);
		$(".choose-images button").prop('disabled', false);
		$(".choose-images button").children('b').text(`(${id_row.length})`);
	} else {
		$(".choose-images input[name=id_image]").val(null);
		$(".choose-images button").prop('disabled', true);
		$(".choose-images button").children('b').text(null);
	}
});

$(document).on('change', '#grouped', function() {
	if ($(this).prop('checked')==true) {
		$("#grouped-alert").removeClass('d-none');
	} else if ($(this).prop('checked')==false) {
		$("#grouped-alert").addClass('d-none');
	}
});

$(document).on('click', '.unchoose-image', function(e) {
	e.preventDefault();
	$(this).parent().parent().parent().remove();
});

if ($(".btn-back ").length > 0) {
	$(".btn-back ").on('click', function(e) {
		window.history.back();
	});
}

if ($(".change-file-type").length > 0) {
	$(".change-file-type").on('click', function() {
		$("#input-file-type").val($(this).data('file-type'));
	});
}

if ($(".change-input-edited").length > 0) {
	$(".change-input-edited").on('keyup change', function() {
		let brand = $(this).data('edit');
		$(`#edit-${brand}`).prop('checked', true);
	});
}

if ($(".change-input-status").length > 0) {
	$(".change-input-status").on('change', function() {
		let brand = $(this).data('brand'),
			input_group = $(`.input-group-${brand}`),
			input = $(`.input-${brand}`);
		if ($(this).prop('checked') == true) {
			input_group.removeClass('disabled');
			input.prop('readonly', false);
		} else if ($(this).prop('checked') == false) {
			input_group.addClass('disabled');
			input.prop('readonly', true);
		}
	});
}

if ($(".choose-image").length > 0) {
	$(".choose-image").on('change', function() {
		const file = this.files[0];
		if (file){
			let reader = new FileReader();
			reader.onload = function(e){
				$("#thumbail-preview").html(null);
				$("#thumbail-preview").append(`<div>${imageEl('Gambar', 'image', e.target.result)}</div>`);
				//$("#thumbail-preview").children().children('img').attr('src', e.target.result);
			}
			reader.readAsDataURL(file);
		}
	});
}

if ($(".choose-images").length > 0) {
	$(".choose-images").on('submit', function(e) {
		e.preventDefault();
		let action = $(this).attr('action'),
			csrf = $("meta[name=csrf-token]").attr('content'),
			id = $(".choose-images input[name=id_image]");
		$.ajax({
			type: 'POST',
			url : action,
			dataType: 'json',
			data: {
				_token: csrf, id: id.val()
			},
			error: function(q,w,e) {
				console.log(q);
				console.log(q.responseText);
			},
			success: function(response) {
				if ($("#single-storage-modal").length > 0) {
					$("#thumbail-preview").html(null);
					$("#single-storage-modal").modal('hide');
					$.each(response, function(i, item) {
						$("#thumbail-preview").append(`<div>${imageEl(item.title, item.file, item.url, 'single')}</div>`);
					});
				} else if ($("#multiple-storage-modal").length > 0) {
					$("#multiple-storage-modal").modal('hide');
					$.each(response, function(i, item) {
						$("#thumbail-preview").append(`<div class="col-6 col-md-3">${imageEl(item.title, item.file, item.url, 'multiple')}<input type="text" name="files_name[]" class="form-control rounded-0" value="${item.title}"></div>`);
					});
				}
				$(".check-image").prop('checked', false);
				setTimeout(() => {
					id.val(null);
					$(".choose-images button").children('b').text(null);
				}, 200);
			}
		});
	});
}

if ($(".choose-youtube").length > 0) {
	$(".choose-youtube").on('submit', function(e) {
		e.preventDefault();
		let action = $(this).attr('action'),
			csrf = $("meta[name=csrf-token]").attr('content'),
			id = $(".choose-youtube input[name=url-input-youtube]");
		$.ajax({
			type: 'POST',
			url : action,
			dataType: 'json',
			data: {
				_token: csrf, id: id.val()
			},
			error: function(q,w,e) {
				console.log(q);
				console.log(q.responseText);
			},
			success: function(response) {
				console.log(response);
				$("#input-youtube-modal").modal('hide');
				$("#thumbail-preview").html(null);
				$.each(response, function(i, item) {
					$("#thumbail-preview").append(`<div>${imageEl(item.title, item.file, item.url)}</div>`);
				});
			}
		});
	});
}

if ($(".counting-input").length > 0) {
	$(".counting-input").on('keyup', function() {
		$(".counting").text($(this).val().length);
	});
}

if ($(".dataTables").length > 0) {
	let url = $(".dataTables").data('list'),
		csrf = $("meta[name=csrf-token]").attr('content');
	var dataTables = $(".dataTables").DataTable({
		responsive: true,
		ordering: false,
		language: {
			search: "_INPUT_",
			searchPlaceholder: "Cari",
			searchClass: "form-control",
			lengthMenu: "_MENU_",
			zeroRecords: "Kosong",
			info: "Data total: _TOTAL_",
			infoEmpty: "",
			paginate: {
				previous: "<i class=\"bx bx-chevron-left\"></i>",
				next: "<i class=\"bx bx-chevron-right\"></i>",
			},
			infoFiltered: "/ _MAX_"
		},
		serverSide: true,
		ajax: {
			url: url,
			type: 'post',
			dataType: 'json',
			data: {
				_token: csrf
			},
			error: function(q,w,e) {
				// console.log(q);
				console.log(q.responseText);
			}
		},
		columns: [
			{ data: "id", name: "id" },
			{ data: "title", name: "title" },
			{ data: "info", name: "info" },
			{ data: "log", name: "log" },
		],
	});
	$(".dataTables_filter").children('label').addClass('d-block p-2');
	$(".dataTables_filter").children('label').children('input').addClass('form-control m-0');
	$(".dataTables_length").children('label').addClass('d-block p-2');
	$(".dataTables_length").children('label').children('select').addClass('form-select m-0');
	$(".dataTables_info").addClass('p-3');
	$(".dataTables_paginate").addClass('p-3');
}

if ($(".dropify").length > 0) {
	$(".dropify").dropify({
		messages: {
			'default': '',
			'replace': '',
			'remove':  '&times;',
		}
	});

	$(".dropify").on('change', function(e) {
		$(".dropify-title").val(e.target.files[0].name)
	});
}

if ($(".form-insert").length > 0) {
	document.addEventListener('keydown', function(event) {
		if (event.ctrlKey && event.key === 's') {
			event.preventDefault();
			$(".form-insert").submit();
		}
	});

	$(".form-insert").on('submit', function(e) {
		e.preventDefault();
		let action = $(this).attr('action');
		$.ajax({
			type: 'POST',
			url : action,
			dataType: 'json',
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData:false,
			error: function(q,w,e) {
				console.log(q);
				console.log(q.responseText);
				$(".form-insert").find("button[type=submit]").prop('disabled', false);
				let message = "<ol style=padding:10px>";
				$.each(q.responseJSON.errors, function(index, value) {
					message += `<li>${value}</li>`;
				});
				message += "</ol>";
				Swal.fire({icon:'error', title:'Error', html:message});
			},
			beforeSend: function() {
				$(".form-insert").find("button[type=submit]").prop('disabled', true);
				Toast.fire({
					icon : 'info',
					title: 'Mohon tunggu',
					text : 'Sedang dalam proses..',
					timer: false
				});
			},
			success: function(response) {
				$(".form-insert").find("button[type=submit]").prop('disabled', false);
				Toast.fire(response.toast);
				if (response.redirect.type=='assign') {
					setTimeout(() => {
						window.location.assign(response.redirect.value);
					}, 1000);
				} else if (response.redirect.type=='dataTables') {
					dataTables.ajax.reload();
					$(".form-insert")[0].reset();
					$('.dropify-clear').click();
				} else if (response.redirect.type=='reload') {
					setTimeout(() => {
						window.location.reload();
					}, 1000);
				} else if (response.redirect.type=='nothing') {
				}
			}
		});
	});
}

if ($(".form-update").length > 0) {
	// $(window).bind('keyup', 'ctrl+s', function(e) {
	// 	if (e.ctrlKey && (e.which == 83)) {
	// 		e.preventDefault();
	// 		$(".form-update").submit();
	// 	}
	// }, false);

	document.addEventListener('keydown', function(event) {
		if (event.ctrlKey && event.key === 's') {
			event.preventDefault();
			$(".form-update").submit();
		}
	});

	$(".form-update").on('submit', function(e) {
		e.preventDefault();
		let action = $(this).attr('action');
		$.ajax({
			type: 'POST',
			url : action,
			dataType: 'json',
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData:false,
			error: function(q,w,e) {
				console.log(q);
				console.log(q.responseText);
				$(".form-update").find("button[type=submit]").prop('disabled', false);
				let message = "<ol style=padding:10px>";
				$.each(q.responseJSON.errors, function(index, value) {
					message += `<li>${value}</li>`;
				});
				message += "</ol>";
				Swal.fire({icon:'error', title:'Error', html:message});
			},
			beforeSend: function() {
				$(".form-update").find("button[type=submit]").prop('disabled', true);
				Toast.fire({
					icon : 'info',
					title: 'Mohon tunggu',
					text : 'Sedang dalam proses..',
					timer: false
				});
			},
			success: function(response) {
				$(".form-update").find("button[type=submit]").prop('disabled', false);
				Toast.fire(response.toast);
				if (response.redirect.type=='assign') {
					setTimeout(() => {
						window.location.assign(response.redirect.value);
					}, 1000);
				} else if (response.redirect.type=='dataTables') {
					dataTables.ajax.reload();
					$(".form-update")[0].reset();
					$('.dropify-clear').click();
				} else if (response.redirect.type=='reload') {
					setTimeout(() => {
						window.location.reload();
					}, 1000);
				} else if (response.redirect.type=='nothing') {
				}
			}
		});
	});
}

if ($(".form-delete").length > 0) {
	$(window).bind('keyup', 'delete', function(e) {
		if (e.which == 46) {
			e.preventDefault();
			$(".form-delete").submit();
		}
	}, false);
	
	$(".form-delete").on('submit', function(e) {
		e.preventDefault();
		let action = $(this).attr('action'),
			csrf = $("meta[name=csrf-token]").attr('content'),
			id = $("input[name=id_delete]").val(),
			message = $(".form-delete").data('message');
		SwalDelete.fire({
			text: message,
		}).then((response) => {
			if (response.isConfirmed) {
				$.ajax({
					type: 'DELETE',
					url : action,
					dataType: 'json',
					data: {
						_token: csrf, id: id
					},
					error: function(q,w,e) {
						console.log(q);
						console.log(q.responseText);
					},
					success: function(response) {
						Toast.fire(response.toast);
						if (response.redirect.type=='assign') {
							setTimeout(() => {
								window.location.assign(response.redirect.value);
							}, 1000);
						} else if (response.redirect.type=='dataTables') {
							dataTables.ajax.reload();
							$(".form-delete input[name=id_delete]").val(null);
							$(".form-delete button").prop('disabled', true);
							$(".form-delete button").children('b').html(null);
						} else if (response.redirect.type=='reload') {
							setTimeout(() => {
								window.location.reload();
							}, 1000);
						} else if (response.redirect.type=='nothing') {
						}
					}
				});
			}
		});
	});
}

if ($(".paste-button").length > 0) {
	$(".paste-button").on('click', function(e) {
		e.preventDefault();
		navigator.clipboard.readText().then(
			cliptext => ($(".paste-input").val(cliptext)),
			err => console.log(err)
		);
	});
}

if ($(".select2").length > 0) {
	$(".select2").select2();
}

if ($(".tag-input").length > 0) {
	var tag_preview = $("#tag-preview"),
		tag_input = $(".tag-input");
	function add_tag(params) {
		return `<span class="badge bg-primary mt-1 me-1"><i class="bx bx-x text-danger cursor-pointer me-1 tag-remove"></i>${params}<input type="hidden" name="tags[]" value="${params}"></span>`;
	}
	$(".tag-button").on('click', function(e) {
		e.preventDefault();
		tag_preview.append(add_tag(tag_input.val()));
		tag_input.val(null);
	});

	$(document).on('click', '.tag-remove', function(e) {
		e.preventDefault();
		$(this).parent().remove();
	});
}

if ($(".mce").length > 0) {
	tinymce.init({// for write post only
		selector: 'textarea.mce',
		plugins: 'preview paste searchreplace autolink directionality code visualblocks visualchars image link table charmap hr pagebreak nonbreaking anchor insertdatetime advlist lists wordcount textpattern noneditable charmap quickbars emoticons',
		imagetools_cors_hosts: ['picsum.photos'],
		menubar: false,
		toolbar: [
			'bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | numlist bullist | outdent indent',
			'fontselect fontsizeselect formatselect',
			'forecolor backcolor removeformat | table | image link | charmap emoticons | pagebreak | code preview |'
		],
		toolbar_sticky: false,
		automatic_uploads: true,
		autosave_ask_before_unload: true,
		autosave_interval: "30s",
		autosave_prefix: "{path}{query}-{id}-",
		autosave_restore_when_empty: false,
		autosave_retention: "2m",
		content_style: 'img {max-width: 100%;}',
		content_css: '//www.tiny.cloud/css/codepen.min.css',
		file_picker_types: 'image',
		file_picker_callback: function (callback, value, meta) {
			if (meta.filetype === 'file') {
				callback('https://www.google.com/logos/google.jpg', { text: 'Google' });
			}
			if (meta.filetype === 'image') {
				let file_picker_input = document.createElement('input');
				file_picker_input.setAttribute('type', 'file');
				file_picker_input.setAttribute('accept', 'image/*');
				file_picker_input.onchange = function () {
					let file_picker_file = this.files[0];
					let file_picker_reader = new FileReader();
					file_picker_reader.onload = function () {
						let blobId = 'blobid' + (new Date()).getTime();
						let blobCache =  tinymce.activeEditor.editorUpload.blobCache;
						let base64 = file_picker_reader.result.split(',')[1];
						let blobInfo = blobCache.create(blobId, file_picker_file, base64);
						blobCache.add(blobInfo);
						callback(blobInfo.blobUri(), { title: file_picker_file.name });
					};
					file_picker_reader.readAsDataURL(file_picker_file);
				};
				file_picker_input.click();
			}
		},
		height: 360,
		image_dimensions: false,
		image_caption: false,
		image_class: false,
		noneditable_noneditable_class: "mceNonEditable",
		contextmenu: "selectall copy cut paste | link",
		setup: function(editor) {
			editor.on('change', function() {
				editor.save();
			});
		}
	});
}